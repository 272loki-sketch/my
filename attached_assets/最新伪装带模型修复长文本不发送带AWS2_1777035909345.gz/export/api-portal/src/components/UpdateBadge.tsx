import { useState, useEffect, useCallback } from "react";

interface VersionData {
  version: string;
  hasUpdate: boolean;
  latestVersion?: string;
  latestReleaseNotes?: string;
  githubRepo?: string;
}

interface Props { baseUrl: string; apiKey: string }

export default function UpdateBadge({ baseUrl }: Props) {
  const [info, setInfo] = useState<VersionData | null>(null);
  const [open, setOpen] = useState(false);
  const [checking, setChecking] = useState(false);
  const [copied, setCopied] = useState(false);

  const fetchVersion = useCallback(async () => {
    try {
      const r = await fetch(`${baseUrl}/api/update/version`);
      if (r.ok) setInfo(await r.json() as VersionData);
    } catch {}
  }, [baseUrl]);

  useEffect(() => {
    fetchVersion();
    const t = setInterval(fetchVersion, 5 * 60 * 1000);
    return () => clearInterval(t);
  }, [fetchVersion]);

  const recheck = async () => {
    setChecking(true);
    await fetchVersion();
    setChecking(false);
  };

  const buildPrompt = (ver: string) =>
    `请帮我把 AI 网关更新到最新版本 ${ver}。\n` +
    `从 GitHub 仓库 https://github.com/panpancloud/ai-gateway-proxy 拉取最新代码，覆盖当前项目文件（无需保留原文件），` +
    `然后运行 pnpm install，最后重启 "artifacts/api-server: API Server" 和 "artifacts/api-portal: web" 两个工作流。`;

  const copyPrompt = async () => {
    if (!info?.latestVersion) return;
    const text = buildPrompt(info.latestVersion);
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const el = document.createElement("textarea");
      el.value = text;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  if (!info) return null;

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        style={{
          display: "inline-flex", alignItems: "center", gap: "5px",
          padding: "3px 10px", borderRadius: "12px",
          border: `1px solid ${info.hasUpdate ? "rgba(251,191,36,0.45)" : "rgba(255,255,255,0.1)"}`,
          background: info.hasUpdate ? "rgba(251,191,36,0.1)" : "rgba(255,255,255,0.05)",
          color: info.hasUpdate ? "#fbbf24" : "#475569",
          fontSize: "11.5px", fontWeight: 600, cursor: "pointer", fontFamily: "Menlo, monospace",
        }}
      >
        {info.hasUpdate && <span style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#fbbf24" }} />}
        v{info.version}
        {info.hasUpdate && <span style={{ fontSize: "10px" }}>↑ {info.latestVersion}</span>}
      </button>

      {open && (
        <div
          onClick={(e) => { if (e.target === e.currentTarget) setOpen(false); }}
          style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)", zIndex: 2000, display: "flex", alignItems: "center", justifyContent: "center", padding: "24px", backdropFilter: "blur(6px)" }}
        >
          <div style={{ background: "hsl(222,47%,12%)", border: "1px solid rgba(99,102,241,0.25)", borderRadius: "16px", width: "100%", maxWidth: "480px", padding: "24px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
              <div>
                <div style={{ fontSize: "16px", fontWeight: 700, color: "#f1f5f9" }}>版本信息</div>
                <div style={{ fontSize: "12px", color: "#475569", marginTop: "2px" }}>当前 v{info.version} · 最新 v{info.latestVersion ?? info.version}</div>
              </div>
              <button onClick={() => setOpen(false)} style={{ background: "none", border: "none", color: "#475569", cursor: "pointer", fontSize: "20px", lineHeight: 1 }}>×</button>
            </div>

            {info.hasUpdate ? (
              <>
                <div style={{ background: "rgba(251,191,36,0.08)", border: "1px solid rgba(251,191,36,0.25)", borderRadius: "10px", padding: "14px", marginBottom: "16px" }}>
                  <div style={{ fontSize: "13px", fontWeight: 600, color: "#fbbf24", marginBottom: "6px" }}>🎉 发现新版本 v{info.latestVersion}</div>
                  {info.latestReleaseNotes && <div style={{ fontSize: "12px", color: "#92400e", lineHeight: 1.5 }}>{info.latestReleaseNotes}</div>}
                </div>
                <div style={{ fontSize: "12px", color: "#64748b", marginBottom: "8px" }}>复制以下提示词，粘贴给 Replit Agent 完成更新：</div>
                <pre style={{ background: "rgba(0,0,0,0.35)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "8px", padding: "12px", fontSize: "11.5px", color: "#a5b4fc", fontFamily: "Menlo, monospace", whiteSpace: "pre-wrap", wordBreak: "break-all", maxHeight: "120px", overflowY: "auto", margin: "0 0 10px" }}>
                  {buildPrompt(info.latestVersion ?? "")}
                </pre>
                <button
                  onClick={copyPrompt}
                  style={{ width: "100%", padding: "10px", borderRadius: "8px", border: `1px solid ${copied ? "rgba(74,222,128,0.4)" : "rgba(99,102,241,0.4)"}`, background: copied ? "rgba(74,222,128,0.1)" : "rgba(99,102,241,0.15)", color: copied ? "#4ade80" : "#a5b4fc", fontSize: "13px", fontWeight: 600, cursor: "pointer" }}
                >
                  {copied ? "✓ 已复制" : "📋 复制更新提示词"}
                </button>
              </>
            ) : (
              <div style={{ textAlign: "center", padding: "20px 0", color: "#4ade80", fontSize: "14px" }}>✓ 已是最新版本</div>
            )}

            <div style={{ marginTop: "14px", display: "flex", justifyContent: "flex-end" }}>
              <button onClick={recheck} disabled={checking} style={{ padding: "7px 16px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.04)", color: checking ? "#334155" : "#475569", fontSize: "12px", cursor: checking ? "not-allowed" : "pointer" }}>
                {checking ? "检测中…" : "重新检测"}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
