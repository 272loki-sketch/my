import { Router, type IRouter, type Request, type Response } from "express";
import { readFileSync, writeFileSync, existsSync, mkdirSync } from "fs";
import { join, dirname } from "path";
import { execFile } from "child_process";
import { promisify } from "util";

const router: IRouter = Router();
const execFileAsync = promisify(execFile);

const GITHUB_OWNER = "panpancloud";
const GITHUB_REPO = "ai-gateway-proxy";
const RAW_VERSION_URL = `https://raw.githubusercontent.com/${GITHUB_OWNER}/${GITHUB_REPO}/main/version.json`;
const WORKSPACE_ROOT = join(process.cwd());

let _updateRunning = false;

function checkKey(req: Request, res: Response): boolean {
  const envKey = process.env.PROXY_API_KEY;
  if (!envKey) return true;
  const auth = req.headers.authorization ?? "";
  const supplied =
    auth.startsWith("Bearer ") ? auth.slice(7).trim() :
    (req.headers["x-api-key"] as string | undefined) ??
    (req.query["key"] as string | undefined) ?? "";
  if (supplied !== envKey) {
    res.status(401).json({ error: "Unauthorized" });
    return false;
  }
  return true;
}

function readLocalVersion(): string {
  try {
    const p = join(WORKSPACE_ROOT, "version.json");
    if (existsSync(p)) {
      const d = JSON.parse(readFileSync(p, "utf8")) as { version?: string };
      return d.version ?? "0.0.0";
    }
  } catch {}
  return "0.0.0";
}

function semverGt(a: string, b: string): boolean {
  const parse = (v: string) => v.replace(/^v/, "").split(".").map(Number);
  const [am, an, ap] = parse(a);
  const [bm, bn, bp] = parse(b);
  if (am !== bm) return am > bm;
  if (an !== bn) return an > bn;
  return ap > bp;
}

router.get("/version", async (_req: Request, res: Response) => {
  const localVersion = readLocalVersion();
  try {
    const r = await fetch(RAW_VERSION_URL, { signal: AbortSignal.timeout(8000) });
    if (!r.ok) throw new Error(`GitHub returned ${r.status}`);
    const remote = await r.json() as { version?: string; releaseNotes?: string };
    const latestVersion = (remote.version ?? localVersion).replace(/^v/, "");
    const localClean = localVersion.replace(/^v/, "");
    const hasUpdate = semverGt(latestVersion, localClean);
    res.json({
      version: localClean,
      latestVersion,
      hasUpdate,
      latestReleaseNotes: remote.releaseNotes ?? "",
      githubRepo: `https://github.com/${GITHUB_OWNER}/${GITHUB_REPO}`,
    });
  } catch {
    res.json({ version: localVersion, latestVersion: localVersion, hasUpdate: false, latestReleaseNotes: "" });
  }
});

router.post("/apply", async (req: Request, res: Response) => {
  if (!checkKey(req, res)) return;
  if (_updateRunning) {
    res.json({ status: "already_running", message: "Update already in progress" });
    return;
  }
  res.json({ status: "started", message: "Update started — server will restart automatically when complete." });
  _updateRunning = true;

  (async () => {
    try {
      const apiUrl = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/git/trees/main?recursive=1`;
      const treeRes = await fetch(apiUrl, { signal: AbortSignal.timeout(15000) });
      if (!treeRes.ok) throw new Error(`GitHub API ${treeRes.status}`);
      const tree = await treeRes.json() as { tree: Array<{ path: string; type: string; url: string }> };
      const blobs = tree.tree.filter((n) => n.type === "blob");
      let written = 0;
      for (const node of blobs) {
        const blobRes = await fetch(node.url, { signal: AbortSignal.timeout(10000) });
        if (!blobRes.ok) continue;
        const blobData = await blobRes.json() as { encoding?: string; content?: string };
        if (blobData.encoding !== "base64" || !blobData.content) continue;
        const content = Buffer.from(blobData.content.replace(/\n/g, ""), "base64").toString("utf8");
        const fullPath = join(WORKSPACE_ROOT, node.path);
        mkdirSync(dirname(fullPath), { recursive: true });
        writeFileSync(fullPath, content, "utf8");
        written++;
      }
      console.log(`[update] wrote ${written} files from GitHub`);
      await execFileAsync("pnpm", ["install", "--no-frozen-lockfile"], { cwd: WORKSPACE_ROOT });
      setTimeout(() => process.exit(0), 500);
    } catch (err) {
      _updateRunning = false;
      console.error("[update] failed:", err instanceof Error ? err.message : err);
    }
  })();
});

router.get("/status", (_req: Request, res: Response) => {
  res.json({ inProgress: _updateRunning, githubRepo: `https://github.com/${GITHUB_OWNER}/${GITHUB_REPO}` });
});

export default router;
