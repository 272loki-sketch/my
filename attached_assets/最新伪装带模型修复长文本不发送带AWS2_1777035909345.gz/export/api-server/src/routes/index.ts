import { Router, type IRouter, type Request, type Response } from "express";
import healthRouter from "./health";
import proxyRouter, { gatewayReady, requireApiKey } from "./proxy";
import settingsRouter from "./settings";
import updateRouter from "./update";
import configRouter from "./config";

const router: IRouter = Router();

router.use(healthRouter);

router.get("/setup-status", (req: Request, res: Response) => {
  const configured = !!(process.env.PROXY_API_KEY);
  const integrationsReady = !!(
    process.env.AI_INTEGRATIONS_OPENAI_API_KEY &&
    process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY &&
    process.env.AI_INTEGRATIONS_GEMINI_API_KEY &&
    process.env.AI_INTEGRATIONS_OPENROUTER_API_KEY
  );
  const storageReady = !!(process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID);
  res.json({ configured, integrationsReady, storageReady });
});

router.use(proxyRouter);
router.use("/settings", settingsRouter);
router.use("/update", updateRouter);
router.use(configRouter);

export default router;
export { gatewayReady, requireApiKey };
