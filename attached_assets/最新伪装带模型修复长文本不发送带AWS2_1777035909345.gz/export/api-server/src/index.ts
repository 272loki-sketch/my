import app from "./app";
import { logger } from "./lib/logger";
import { gatewayReady } from "./routes";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error("PORT environment variable is required but was not provided.");
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

// 35-minute socket/keep-alive timeout — must exceed the 30-minute AI SDK
// timeout so the connection is never killed by the OS before a response arrives.
// This is critical for ultra-long (150K-200K token) requests that take a long
// time for the upstream AI provider to process and stream back.
const SERVER_TIMEOUT_MS = 35 * 60 * 1000; // 35 min

gatewayReady.then(() => {
  const server = app.listen(port, (err) => {
    if (err) {
      logger.error({ err }, "Error listening on port");
      process.exit(1);
    }
    logger.info({ port }, "Server listening — all persistence loaded");
  });

  server.setTimeout(SERVER_TIMEOUT_MS);
  server.keepAliveTimeout = SERVER_TIMEOUT_MS;
  server.headersTimeout = SERVER_TIMEOUT_MS + 5000;
}).catch((err: unknown) => {
  logger.error({ err }, "Gateway init failed");
  process.exit(1);
});
