import { type Request, type Response, type NextFunction } from "express";
import { rateLimit } from "express-rate-limit";

// ─── Scanner / Bot User-Agent blocklist ──────────────────────────────────────
// Common automated scanners, pentest tools, and credential-stuffing bots
const SCANNER_UA_PATTERNS = [
  /sqlmap/i,
  /nikto/i,
  /masscan/i,
  /nmap/i,
  /zgrab/i,
  /nuclei/i,
  /dirbuster/i,
  /gobuster/i,
  /wfuzz/i,
  /hydra/i,
  /medusa/i,
  /burpsuite/i,
  /owasp/i,
  /havij/i,
  /acunetix/i,
  /nessus/i,
  /openvas/i,
  /metasploit/i,
  /w3af/i,
  /skipfish/i,
  /httpscan/i,
  /libwww-perl/i,
  /lwp-request/i,
  /scrapy/i,
  /massexplo/i,
  /fuzz/i,
  /exploit/i,
  /attack/i,
  /vuln/i,
  /dirsearch/i,
  /feroxbuster/i,
  /ffuf/i,
  /zap\//i,
];

// ─── Decoy HTML — looks like a generic "under construction" business site ────
const DECOY_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Welcome</title>
<style>
  *{margin:0;padding:0;box-sizing:border-box}
  body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
    background:#f8f9fa;display:flex;align-items:center;justify-content:center;
    min-height:100vh;color:#333}
  .card{background:#fff;border-radius:12px;padding:48px 56px;text-align:center;
    box-shadow:0 2px 16px rgba(0,0,0,.08);max-width:440px}
  h1{font-size:1.6rem;font-weight:600;margin-bottom:12px}
  p{color:#666;line-height:1.6;font-size:.95rem}
  .dot{display:inline-block;width:8px;height:8px;border-radius:50%;
    background:#4CAF50;margin-right:6px;vertical-align:middle}
</style>
</head>
<body>
<div class="card">
  <h1>Service Portal</h1>
  <p><span class="dot"></span>All systems operational</p>
  <p style="margin-top:16px;font-size:.85rem;color:#999">
    &copy; 2025 &nbsp;&middot;&nbsp; v1.0
  </p>
</div>
</body>
</html>`;

// ─── Middleware: strip server-identity headers ───────────────────────────────
export function stripFingerprint(req: Request, res: Response, next: NextFunction) {
  res.removeHeader("X-Powered-By");
  res.removeHeader("Server");
  res.setHeader("Server", "nginx");
  next();
}

// ─── Middleware: block known scanner user-agents ──────────────────────────────
export function blockScanners(req: Request, res: Response, next: NextFunction) {
  const ua = req.headers["user-agent"] ?? "";
  if (SCANNER_UA_PATTERNS.some((p) => p.test(ua))) {
    res.status(200).send(DECOY_HTML);
    return;
  }
  next();
}

// ─── Middleware: serve decoy page for anything outside /api/* ────────────────
export function decoyFallback(req: Request, res: Response) {
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.status(200).send(DECOY_HTML);
}

// ─── Middleware: block common vulnerability probe paths ──────────────────────
const PROBE_PATHS = [
  /^\/wp-/i,
  /^\/\.env/i,
  /^\/\.git/i,
  /^\/admin/i,
  /^\/phpmyadmin/i,
  /^\/actuator/i,
  /^\/console/i,
  /^\/manager/i,
  /^\/xmlrpc/i,
  /^\/cgi-bin/i,
  /^\/etc\//i,
  /^\/proc\//i,
  /^\/config/i,
  /\/\.\.\//,
  /select.*from/i,
  /<script/i,
  /union.*select/i,
];

export function blockProbes(req: Request, res: Response, next: NextFunction) {
  const path = req.path + (req.originalUrl.includes("?") ? "?" + req.originalUrl.split("?")[1] : "");
  if (PROBE_PATHS.some((p) => p.test(path))) {
    res.status(200).send(DECOY_HTML);
    return;
  }
  next();
}

// ─── Rate limiter: global (all routes) ───────────────────────────────────────
export const globalRateLimit = rateLimit({
  windowMs: 60 * 1000,
  max: 120,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  skip: () => false,
  handler: (_req: Request, res: Response) => {
    res.status(429).json({ error: { message: "Too many requests", type: "rate_limit_error" } });
  },
});

// ─── Rate limiter: auth endpoint (brute-force protection) ────────────────────
export const authRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 30,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  handler: (_req: Request, res: Response) => {
    res.status(429).json({ error: { message: "Too many requests", type: "rate_limit_error" } });
  },
});

// ─── Middleware: sanitize error responses (no stack traces in production) ────
export function sanitizeErrors(
  err: Error,
  _req: Request,
  res: Response,
  _next: NextFunction,
) {
  const isProd = process.env.NODE_ENV === "production";
  res.status(500).json({
    error: {
      message: isProd ? "Internal server error" : (err.message ?? "Internal server error"),
      type: "server_error",
    },
  });
}
