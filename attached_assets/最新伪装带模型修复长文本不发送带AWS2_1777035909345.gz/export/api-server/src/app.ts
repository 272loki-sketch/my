import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import helmet from "helmet";
import router from "./routes";
import { logger } from "./lib/logger";
import {
  stripFingerprint,
  blockScanners,
  blockProbes,
  decoyFallback,
  globalRateLimit,
  authRateLimit,
  sanitizeErrors,
} from "./middleware/security";

const app: Express = express();

// ── 0. Trust Replit's reverse-proxy so rate-limiter can read real client IP ───
//       Without this, express-rate-limit throws ERR_ERL_UNEXPECTED_X_FORWARDED_FOR
//       and crashes the middleware chain, silently dropping the connection.
app.set("trust proxy", 1);

// ── 1. Disable Express "X-Powered-By" at the framework level ─────────────────
app.disable("x-powered-by");

// ── 2. Security headers via helmet (hides server tech stack) ──────────────────
app.use(
  helmet({
    contentSecurityPolicy: false,
    crossOriginEmbedderPolicy: false,
  }),
);

// ── 3. Strip / spoof remaining fingerprint headers ────────────────────────────
app.use(stripFingerprint);

// ── 4. Block scanner user-agents before any processing ───────────────────────
app.use(blockScanners);

// ── 5. Block common vulnerability probe paths ─────────────────────────────────
app.use(blockProbes);

// ── 6. Global rate limit (120 req/min per IP) ─────────────────────────────────
app.use(globalRateLimit);

// ── 7. Stricter rate limit on auth-sensitive API endpoints ────────────────────
app.use("/api/v1", authRateLimit);

// ── 8. Logging ────────────────────────────────────────────────────────────────
app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);

// ── 9. Body parsing ───────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json({ limit: "100mb" }));
app.use(express.urlencoded({ extended: true, limit: "100mb" }));

// ── 10. Real API routes ───────────────────────────────────────────────────────
app.use("/api", router);

// ── 11. Decoy fallback — everything else looks like a plain website ───────────
app.use(decoyFallback);

// ── 12. Sanitize error responses (no stack traces leaked) ─────────────────────
app.use(sanitizeErrors);

export default app;
