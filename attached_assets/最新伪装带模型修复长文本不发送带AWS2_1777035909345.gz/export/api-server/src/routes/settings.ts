import { Router, type IRouter, type Request, type Response } from "express";
import { readJson, writeJson } from "../lib/cloudPersist";

const router: IRouter = Router();

interface GatewaySettings {
  sillyTavernMode: boolean;
}

let _settings: GatewaySettings = { sillyTavernMode: false };
let _ready = false;

export async function loadSettings(): Promise<void> {
  const saved = await readJson<GatewaySettings>("gateway_settings.json");
  if (saved) _settings = { sillyTavernMode: !!saved.sillyTavernMode };
  _ready = true;
}

async function persistSettings(): Promise<void> {
  await writeJson("gateway_settings.json", _settings);
}

export function getSillyTavernMode(): boolean {
  return _settings.sillyTavernMode;
}

function checkKey(req: Request, res: Response): boolean {
  const envKey = process.env.PROXY_API_KEY;
  if (!envKey) {
    res.status(500).json({ error: { message: "PROXY_API_KEY not configured", type: "server_error" } });
    return false;
  }
  const auth = req.headers.authorization ?? "";
  const supplied =
    auth.startsWith("Bearer ") ? auth.slice(7).trim() :
    (req.headers["x-api-key"] as string | undefined) ??
    (req.query["key"] as string | undefined) ?? "";
  if (supplied !== envKey) {
    res.status(401).json({ error: { message: "Invalid API key", type: "auth_error" } });
    return false;
  }
  return true;
}

router.get("/sillytavern", (req: Request, res: Response) => {
  if (!checkKey(req, res)) return;
  res.json({ enabled: _settings.sillyTavernMode });
});

router.post("/sillytavern", async (req: Request, res: Response) => {
  if (!checkKey(req, res)) return;
  const { enabled } = req.body as { enabled?: boolean };
  if (typeof enabled !== "boolean") {
    res.status(400).json({ error: "enabled must be boolean" });
    return;
  }
  _settings.sillyTavernMode = enabled;
  await persistSettings();
  res.json({ ok: true, enabled: _settings.sillyTavernMode });
});

export default router;
