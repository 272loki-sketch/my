import { Router } from "express";

const configRouter = Router();

configRouter.get("/config", (req, res) => {
  const providers = [
    {
      name: "OpenAI",
      slug: "openai",
      configured: !!(process.env.AI_INTEGRATIONS_OPENAI_API_KEY && process.env.AI_INTEGRATIONS_OPENAI_BASE_URL),
      baseUrl: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL ?? "",
    },
    {
      name: "Anthropic",
      slug: "anthropic",
      configured: !!(process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY && process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL),
      baseUrl: process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL ?? "",
    },
    {
      name: "Gemini",
      slug: "gemini",
      configured: !!(process.env.AI_INTEGRATIONS_GEMINI_API_KEY && process.env.AI_INTEGRATIONS_GEMINI_BASE_URL),
      baseUrl: process.env.AI_INTEGRATIONS_GEMINI_BASE_URL ?? "",
    },
    {
      name: "OpenRouter",
      slug: "openrouter",
      configured: !!(process.env.AI_INTEGRATIONS_OPENROUTER_API_KEY && process.env.AI_INTEGRATIONS_OPENROUTER_BASE_URL),
      baseUrl: process.env.AI_INTEGRATIONS_OPENROUTER_BASE_URL ?? "",
    },
  ];

  const domains = process.env.REPLIT_DOMAINS?.split(",") ?? [];
  const primaryDomain = domains[0] ?? "localhost";
  const proxyBaseUrl = `https://${primaryDomain}/api`;

  res.json({
    proxyBaseUrl,
    providers,
  });
});

export default configRouter;
