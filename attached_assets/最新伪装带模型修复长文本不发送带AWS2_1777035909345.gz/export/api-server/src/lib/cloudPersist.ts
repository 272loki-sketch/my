import { Storage } from "@google-cloud/storage";
import { readFileSync, writeFileSync, existsSync, mkdirSync } from "fs";
import { resolve, dirname } from "path";

const BUCKET_ID = process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID;
const IS_PROD = !!process.env.REPLIT_DEPLOYMENT;
const GCS_PREFIX = IS_PROD ? "config/" : "config_dev/";
const LOCAL_DIR = IS_PROD ? "data_prod" : "data_dev";

// Replit sidecar auth endpoint — required in both dev and prod.
// Using new Storage() without credentials causes Replit's service account
// to get a 403 because it tries the GCP metadata server instead.
const REPLIT_SIDECAR = "http://127.0.0.1:1106";

let _gcs: Storage | null = null;
function gcs(): Storage {
  if (!_gcs) {
    _gcs = new Storage({
      credentials: {
        audience: "replit",
        subject_token_type: "access_token",
        token_url: `${REPLIT_SIDECAR}/token`,
        type: "external_account",
        credential_source: {
          url: `${REPLIT_SIDECAR}/credential`,
          format: {
            type: "json",
            subject_token_field_name: "access_token",
          },
        },
        universe_domain: "googleapis.com",
      } as Record<string, unknown>,
      projectId: "",
    });
  }
  return _gcs;
}

export async function readJson<T>(name: string): Promise<T | null> {
  if (BUCKET_ID) {
    try {
      const f = gcs().bucket(BUCKET_ID).file(`${GCS_PREFIX}${name}`);
      const [exists] = await f.exists();
      if (!exists) return null;
      const [buf] = await f.download();
      return JSON.parse(buf.toString("utf8")) as T;
    } catch (err) {
      console.warn(`[persist] GCS read error for ${name}, using local:`, (err as Error).message?.slice(0, 80));
      return null;
    }
  }
  const p = resolve(process.cwd(), LOCAL_DIR, name);
  if (!existsSync(p)) return null;
  try { return JSON.parse(readFileSync(p, "utf8")) as T; } catch { return null; }
}

export async function writeJson<T>(name: string, data: T): Promise<void> {
  const json = JSON.stringify(data, null, 2);
  if (BUCKET_ID) {
    try {
      await gcs().bucket(BUCKET_ID).file(`${GCS_PREFIX}${name}`).save(json, { contentType: "application/json" });
      return;
    } catch (err) {
      console.error(`[persist] GCS write error for ${name}, falling back to local:`, (err as Error).message?.slice(0, 120));
    }
  }
  const p = resolve(process.cwd(), LOCAL_DIR, name);
  mkdirSync(dirname(p), { recursive: true });
  writeFileSync(p, json, "utf8");
}
