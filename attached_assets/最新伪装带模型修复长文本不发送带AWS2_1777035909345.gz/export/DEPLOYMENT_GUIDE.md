# AI Gateway 部署指南

> 适用平台：**Replit**（pnpm monorepo 模板）
> 最后更新：2026-04-13

---

## 项目结构

```
artifacts/
  api-server/        Express 后端，代理 OpenAI / Anthropic / Gemini / OpenRouter
  api-portal/        React 前端，管理面板
lib/
  api-zod/           Zod schema（HealthCheckResponse 等）
```

---

## 一、环境变量与 Secret

### 必须设置的 Secret（Replit Secrets 面板手动填写）

| 变量名 | 说明 |
|--------|------|
| `PROXY_API_KEY` | 网关访问密码，客户端用它做 Bearer 认证。自定义一个强密码即可。 |

### 由 Replit 自动注入的变量（通过内置 AI Integrations 配置，无需手动填写）

| 变量名 | 来源 |
|--------|------|
| `AI_INTEGRATIONS_OPENAI_API_KEY` | Replit AI Integrations → OpenAI |
| `AI_INTEGRATIONS_OPENAI_BASE_URL` | 同上 |
| `AI_INTEGRATIONS_ANTHROPIC_API_KEY` | Replit AI Integrations → Anthropic |
| `AI_INTEGRATIONS_ANTHROPIC_BASE_URL` | 同上 |
| `AI_INTEGRATIONS_GEMINI_API_KEY` | Replit AI Integrations → Google |
| `AI_INTEGRATIONS_GEMINI_BASE_URL` | 同上 |
| `AI_INTEGRATIONS_OPENROUTER_API_KEY` | Replit AI Integrations → OpenRouter |
| `AI_INTEGRATIONS_OPENROUTER_BASE_URL` | 同上 |
| `DEFAULT_OBJECT_STORAGE_BUCKET_ID` | Replit Object Storage |
| `PUBLIC_OBJECT_SEARCH_PATHS` | 同上 |
| `PRIVATE_OBJECT_DIR` | 同上 |

---

## 二、首次部署步骤

### 1. 在代码执行沙箱中依次调用以下函数（顺序执行，等每个完成再执行下一个）

```javascript
// OpenAI
await setupReplitAIIntegrations({
  providerSlug: "openai",
  providerUrlEnvVarName: "AI_INTEGRATIONS_OPENAI_BASE_URL",
  providerApiKeyEnvVarName: "AI_INTEGRATIONS_OPENAI_API_KEY"
});

// Anthropic
await setupReplitAIIntegrations({
  providerSlug: "anthropic",
  providerUrlEnvVarName: "AI_INTEGRATIONS_ANTHROPIC_BASE_URL",
  providerApiKeyEnvVarName: "AI_INTEGRATIONS_ANTHROPIC_API_KEY"
});

// Gemini（providerSlug 必须是 "google"，不是 "gemini"）
await setupReplitAIIntegrations({
  providerSlug: "google",
  providerUrlEnvVarName: "AI_INTEGRATIONS_GEMINI_BASE_URL",
  providerApiKeyEnvVarName: "AI_INTEGRATIONS_GEMINI_API_KEY"
});

// OpenRouter
await setupReplitAIIntegrations({
  providerSlug: "openrouter",
  providerUrlEnvVarName: "AI_INTEGRATIONS_OPENROUTER_BASE_URL",
  providerApiKeyEnvVarName: "AI_INTEGRATIONS_OPENROUTER_API_KEY"
});

// Object Storage（用于持久化配置到 GCS）
await setupObjectStorage();
```

### 2. 在 Replit Secrets 面板手动添加

```
PROXY_API_KEY = <你的访问密码>
```

### 3. 重启所有 Workflow

- `artifacts/api-server: API Server`
- `artifacts/api-portal: web`

### 4. 验证

访问管理面板，状态角标显示"在线"（绿色）即为成功。

---

## 三、API 端点说明

所有端点前缀均为 `/api`，认证方式为：

```
Authorization: Bearer <PROXY_API_KEY>
```

| 端点 | 说明 |
|------|------|
| `POST /api/v1/chat/completions` | OpenAI 兼容格式，支持所有模型 |
| `POST /api/v1/messages` | Anthropic Messages 原生格式 |
| `GET /api/v1/models` | 模型列表 |
| `GET /api/healthz` | 健康检查（无需认证） |
| `GET /api/setup-status` | 配置状态 |
| `GET /api/v1/stats` | 请求统计 |

### 客户端连接示例（OpenAI 兼容）

```
Base URL: https://<your-repl>.replit.app/api
API Key:  <PROXY_API_KEY>
```

---

## 四、模型路由规则

| 模型 ID 格式 | 路由到 |
|-------------|--------|
| `gpt-*`, `o3`, `o4-mini` | OpenAI |
| `claude-*` | Anthropic 原生 |
| `anthropic/claude-opus-4.5o` | Anthropic 原生（`claude-opus-4-5` 别名） |
| `anthropic/claude-opus-4.1o` | Anthropic 原生（`claude-opus-4-1` 别名） |
| `gemini-*` | Gemini |
| `x-ai/*`, `meta-llama/*`, `deepseek/*` 等 | OpenRouter |
| `AWS/claude-*` | OpenRouter + Bedrock 强制路由 |
| 包含 `/` 的未知 ID | 自动走 OpenRouter |

### 模型后缀说明

- `-thinking`：启用扩展思考，隐藏思考过程
- `-thinking-visible`：启用扩展思考，思考过程以 `<thinking>` 块显示在回复中

---

## 五、超时与大输出配置

服务器针对长上下文（150K–200K token）请求进行了专项配置：

| 配置项 | 值 | 说明 |
|--------|----|------|
| AI SDK timeout | 30 分钟 | 所有 AI 客户端的请求超时 |
| Node HTTP server timeout | 35 分钟 | 必须大于 SDK timeout |
| keepAliveTimeout | 35 分钟 | 同上 |
| headersTimeout | 35 分 5 秒 | 必须大于 keepAliveTimeout |
| SSE keepalive ping | 每 5 秒 | 防止代理层因空闲切断 SSE 连接 |

---

## 六、安全伪装层（Security Middleware）

本项目内置了完整的流量伪装 + 反扫描系统，实现于 `artifacts/api-server/src/middleware/security.ts` 与 `src/app.ts`。**无需额外配置**，部署即生效。

### 6.1 中间件注册顺序（严格不可调换）

`app.ts` 中的注册顺序如下，**顺序即逻辑，调换任意两层都可能导致安全失效或服务崩溃**：

```
① app.set("trust proxy", 1)      ← 必须第一行！否则 rate-limiter 崩溃
② app.disable("x-powered-by")    ← Express 自带 X-Powered-By 头禁用
③ helmet(...)                    ← 标准安全响应头（隐藏技术栈指纹）
④ stripFingerprint               ← 对外伪装：Server 头改写为 "nginx"
⑤ blockScanners                  ← Agent 伪装检测：屏蔽扫描器 UA
⑥ blockProbes                    ← 路径探测拦截：屏蔽漏洞扫描路径
⑦ globalRateLimit                ← 全局限流：120 次/分钟/IP
⑧ authRateLimit (仅 /api/v1)     ← 认证端点限流：30 次/15分钟/IP
⑨ pinoHttp                       ← 结构化日志
⑩ cors / bodyParser              ← 跨域 + 请求体解析
⑪ 真实 API 路由 (/api/*)
⑫ decoyFallback                  ← 流量伪装：其他所有请求返回诱饵页
⑬ sanitizeErrors                 ← 错误净化：生产环境屏蔽堆栈信息
```

---

### 6.2 对外伪装（请求头伪装 / Server 身份伪装）

**实现**：`stripFingerprint` 中间件 + `helmet`

- 移除 Express 默认的 `X-Powered-By: Express` 头
- 将 `Server` 响应头改写为 `Server: nginx`，让扫描器认为这是一台 nginx 服务器而非 Node.js
- `helmet` 额外添加：`X-Frame-Options`、`X-Content-Type-Options`、`Strict-Transport-Security` 等标准安全头

```typescript
// 伪装效果示例（实际响应头）
Server: nginx
X-Frame-Options: SAMEORIGIN
X-Content-Type-Options: nosniff
// 无 X-Powered-By
```

---

### 6.3 Agent 伪装检测（扫描器 UA 黑名单）

**实现**：`blockScanners` 中间件

检测请求的 `User-Agent` 是否匹配已知渗透测试工具 / 扫描器特征，匹配则**返回 200 OK + 诱饵 HTML**（不是 403，避免暴露存在拦截逻辑）。

被拦截的工具包括：

| 类别 | 工具 |
|------|------|
| SQL 注入 | sqlmap, havij |
| 端口/资产扫描 | nmap, masscan, zgrab, httpscan |
| Web 漏洞扫描 | nikto, nuclei, acunetix, nessus, openvas, w3af, skipfish |
| 目录爆破 | dirbuster, gobuster, feroxbuster, ffuf, dirsearch, wfuzz |
| 渗透框架 | burpsuite, owasp-zap, metasploit |
| 密码爆破 | hydra, medusa |
| 脚本/爬虫 | scrapy, libwww-perl, lwp-request |
| 模糊测试 | fuzz, exploit, attack, vuln（关键词匹配） |

---

### 6.4 路径探测拦截（漏洞路径黑名单）

**实现**：`blockProbes` 中间件

对以下路径的请求**返回 200 OK + 诱饵 HTML**：

| 路径模式 | 对应攻击类型 |
|---------|------------|
| `/wp-*` | WordPress 漏洞扫描 |
| `/.env`, `/.git` | 敏感文件泄露 |
| `/phpmyadmin`, `/xmlrpc` | PHP 服务探测 |
| `/admin`, `/console`, `/manager` | 后台管理入口探测 |
| `/actuator` | Spring Boot 端点泄露 |
| `/cgi-bin`, `/etc/`, `/proc/` | 路径穿越 / 系统文件访问 |
| `/config` | 配置文件探测 |
| `/../` | 目录穿越 |
| `select.*from`, `union.*select` | URL 中的 SQL 注入 |
| `<script` | XSS 探测 |

---

### 6.5 流量伪装（诱饵页 / Decoy Fallback）

**实现**：`decoyFallback` 中间件（最后一个非错误中间件）

所有**不匹配 `/api/*`** 的请求（包括随机路径、扫描路径未被 `blockProbes` 捕获的情况），都会返回：

```
HTTP/1.1 200 OK
Content-Type: text/html

<!DOCTYPE html>
<html>
  <title>Welcome</title>
  <!-- 看起来像一个普通的企业门户网站 -->
  <h1>Service Portal</h1>
  <p>All systems operational</p>
</html>
```

**关键点**：返回 `200 OK` 而不是 `404`，让扫描器认为这是一个正常运行的普通网站，没有任何值得攻击的端点。

---

### 6.6 错误信息净化

**实现**：`sanitizeErrors` 错误处理中间件

- **开发环境**（`NODE_ENV=development`）：返回实际错误信息，方便调试
- **生产环境**（`NODE_ENV=production`）：所有 500 错误统一返回 `"Internal server error"`，不泄露堆栈、文件路径、模块名等信息

---

### 6.7 完整伪装效果总结

从外部视角看，这台服务器表现为：

```
身份：nginx Web 服务器（不是 Node.js / Express）
前台：普通企业门户网站（"Service Portal - All systems operational"）
行为：对所有探测返回 200，不暴露 4xx/5xx，不暴露任何有用信息
API：隐藏在 /api/ 路径下，需要 Bearer Token 才能访问
```

**注意**：这些伪装**不影响正常的 `/api/*` 调用**，只针对不认识正确路径的访问者生效。

---

## 七、本次 Replit 部署遇到的问题与解决方案

### 问题 1：`@workspace/db` 依赖导致构建失败

**现象**：`api-server` 原 `package.json` 声明了 `@workspace/db` 依赖，该包需要 `DATABASE_URL`，但本项目路由层实际上不使用数据库。

**原因**：模板脚手架自动加入了数据库依赖，而新的网关代码并不需要它。

**解决方案**：从 `api-server/package.json` 中移除 `@workspace/db`，只保留 `@workspace/api-zod`（健康检查路由用到了它）。

---

### 问题 2：Gemini AI Integration 的 `providerSlug` 必须是 `"google"`

**现象**：调用 `setupReplitAIIntegrations({ providerSlug: "gemini", ... })` 返回失败或无效。

**原因**：Replit AI Integrations 内部将 Gemini 注册为 `google` provider。

**解决方案**：改用 `providerSlug: "google"`，环境变量名仍然是 `AI_INTEGRATIONS_GEMINI_*`。

---

### 问题 3：大输出（15 万字）时 Claude 流式连接秒断

**现象**：使用 `anthropic/claude-opus-4.1o` 等模型，当输出文本量达到约 15 万字时，SSE 流式连接突然关闭，客户端（如 SillyTavern）看到连接无预警断开。

**根本原因**：两个叠加问题：

1. **SSE keepalive 间隔过长（15 秒）**：Claude 生成大量文本时，每个 chunk 之间的间隔可能超过代理层的空闲超时阈值，导致 Replit 反向代理主动切断连接。

2. **流中断时无错误处理**：上游 AI Integration 代理切断连接后，`for await` 循环抛出异常，原代码直接执行 `finally { res.end() }`，不发送任何通知就关闭 SSE 流。客户端收不到 `[DONE]` 也收不到错误信息，表现为"秒断连"。

**解决方案**：

- 将 SSE keepalive 间隔从 **15 秒改为 5 秒**，确保代理层始终认为连接活跃。
- 在 `handleClaude` 和 `handleOpenAI` 的 `for await` 循环外增加 `catch` 块：
  - 若已有输出（`ttftMs !== undefined`），在回复内容末尾追加 `[Stream error: <错误信息>]` 提示
  - 无论如何都发送 `data: [DONE]\n\n` 再关闭连接，防止客户端挂起等待

```typescript
// 修复后的结构（Claude handler 示例）
try {
  for await (const ev of streamResp) {
    // ... 正常处理事件 ...
  }
  sseWrite(res, "data: [DONE]\n\n");
} catch (streamErr) {
  const errMsg = streamErr instanceof Error ? streamErr.message.slice(0, 300) : "Stream interrupted";
  try {
    if (ttftMs !== undefined) {
      // 已有输出则附加错误提示
      sseWrite(res, `data: ${JSON.stringify({ ...errorChunk, choices: [{ delta: { content: `\n\n[Stream error: ${errMsg}]` }, finish_reason: "stop" }] })}\n\n`);
    }
    sseWrite(res, "data: [DONE]\n\n");  // 始终发送 DONE
  } catch {}
  throw streamErr;
} finally {
  clearInterval(keepalive);
  res.end();
}
```

---

### 问题 4：`trust proxy` 设置位置错误导致 rate limiter 崩溃

**现象**：`express-rate-limit` 抛出 `ERR_ERL_UNEXPECTED_X_FORWARDED_FOR` 并使中间件链静默中断。

**原因**：`app.set("trust proxy", 1)` 必须是 Express 应用的**第一条**语句，在所有中间件之前。Replit 部署环境使用反向代理，`X-Forwarded-For` 头由代理注入，rate limiter 在未信任代理的情况下收到该头会报错。

**解决方案**：将 `app.set("trust proxy", 1)` 移至 `app.ts` 文件最顶部，其余中间件全部在其后注册。

---

### 问题 5：GCS 持久化使用 Replit sidecar 认证

**说明**：`cloudPersist.ts` 中的 `@google-cloud/storage` 客户端不能使用 `new Storage()` 无参构造（会尝试读取 Google ADC 凭证，在 Replit 环境中失败）。

**解决方案**：使用 Replit sidecar 地址 `http://127.0.0.1:1106` 作为自定义认证端点，由 Replit 平台自动注入凭证，无需任何手动配置。

---

## 八、SillyTavern 专项说明

管理面板中可开启"SillyTavern 模式"（`/api/settings/sillytavern`）。开启后，发往 Anthropic 的非工具调用请求会自动在消息末尾追加「继续」，防止模型在长文本中途截断输出。

**连接配置**（SillyTavern → API → OpenAI 兼容）：

```
API URL:    https://<your-repl>.replit.app/api
API Key:    <PROXY_API_KEY>
```

---

## 九、本地开发

```bash
# 安装依赖
pnpm install

# 启动后端（端口 8080）
pnpm --filter @workspace/api-server run dev

# 启动前端（端口 24927）
pnpm --filter @workspace/api-portal run dev
```

开发环境下配置持久化到本地 `data_dev/` 目录，生产环境写入 GCS `config/` 前缀。

---

## 十、发布到生产

在 Replit 管理面板点击 **Publish / Deploy** 即可。发布后应用获得固定的 `.replit.app` 域名，所有配置（模型开关、路由设置、好友节点等）通过 Object Storage 跨重启持久化。

---

## 十一、常见故障排查

| 现象 | 可能原因 | 解决方法 |
|------|----------|----------|
| 管理面板一直显示"离线" | `PROXY_API_KEY` 未设置或服务器未启动 | 检查 Secrets，重启 api-server workflow |
| 某 AI 提供商报 500 | 对应 `AI_INTEGRATIONS_*` 变量未配置 | 重新运行 `setupReplitAIIntegrations` |
| 流式输出中途断开（有错误提示） | 上游连接被代理层切断 | 查看错误信息；如持续发生考虑降低单次输出量 |
| 流式输出中途断开（无任何提示） | 旧版本代码，keepalive 不足 | 升级到修复版本（v1.1.6+）|
| GCS 写入失败 | Object Storage 未配置或超出配额 | 检查 `DEFAULT_OBJECT_STORAGE_BUCKET_ID` 是否存在 |
| 配置向导一直弹出 | `PROXY_API_KEY` 未注入到服务器进程 | 设置 Secret 后重启 workflow |
