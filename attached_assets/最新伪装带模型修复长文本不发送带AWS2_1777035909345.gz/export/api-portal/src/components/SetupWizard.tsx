import { useState, useEffect, useRef, useCallback } from "react";

interface Props {
  baseUrl: string;
  onComplete: (apiKey?: string) => void;
  onDismiss: () => void;
}

interface CopyBlock { text: string }
interface Action { label: string; value: string; primary?: boolean }
interface Message {
  id: number;
  from: "agent" | "user";
  text: string;
  copyBlocks?: CopyBlock[];
  actions?: Action[];
}

interface SetupStatus { configured: boolean; integrationsReady: boolean; storageReady: boolean }

function buildConfigPrompt(
  apiKey: string,
  opts: { needIntegrations: boolean; needStorage: boolean }
): string {
  const steps: string[] = [];
  let n = 0;

  steps.push(`步骤 ${++n}：添加 Secret — PROXY_API_KEY
   我已经选好了自己的访问密码，请将以下值原封不动地写入 Secrets，不要修改、不要随机生成：
   PROXY_API_KEY = ${apiKey}`);

  if (opts.needIntegrations) {
    steps.push(`步骤 ${++n}：开通 Replit AI Integrations（四个 provider 全部需要）
   【重要】这是 Replit 平台内置功能，完全不需要我提供任何第三方 API Key（OpenAI、Anthropic、Gemini、OpenRouter 均由平台免费提供）。
   请在 code_execution 工具中依次执行以下四条命令（必须逐条顺序执行，等上一条完成再执行下一条）：

   const r1 = await setupReplitAIIntegrations({ providerSlug: "openai", providerUrlEnvVarName: "AI_INTEGRATIONS_OPENAI_BASE_URL", providerApiKeyEnvVarName: "AI_INTEGRATIONS_OPENAI_API_KEY" });
   console.log("OpenAI:", JSON.stringify(r1));

   const r2 = await setupReplitAIIntegrations({ providerSlug: "anthropic", providerUrlEnvVarName: "AI_INTEGRATIONS_ANTHROPIC_BASE_URL", providerApiKeyEnvVarName: "AI_INTEGRATIONS_ANTHROPIC_API_KEY" });
   console.log("Anthropic:", JSON.stringify(r2));

   const r3 = await setupReplitAIIntegrations({ providerSlug: "gemini", providerUrlEnvVarName: "AI_INTEGRATIONS_GEMINI_BASE_URL", providerApiKeyEnvVarName: "AI_INTEGRATIONS_GEMINI_API_KEY" });
   console.log("Gemini:", JSON.stringify(r3));

   const r4 = await setupReplitAIIntegrations({ providerSlug: "openrouter", providerUrlEnvVarName: "AI_INTEGRATIONS_OPENROUTER_BASE_URL", providerApiKeyEnvVarName: "AI_INTEGRATIONS_OPENROUTER_API_KEY" });
   console.log("OpenRouter:", JSON.stringify(r4));

   四条全部成功后，环境变量会自动注入，无需手动操作。`);
  }

  if (opts.needStorage) {
    steps.push(`步骤 ${++n}：开通云端持久化存储（App Storage）
   在 code_execution 工具中执行以下 JavaScript，开通属于本项目的独立 GCS 存储桶：

   const result = await setupObjectStorage();
   console.log(JSON.stringify(result));

   执行成功后 Replit 会自动写入 DEFAULT_OBJECT_STORAGE_BUCKET_ID 等环境变量。`);
  }

  return `请帮我完成 AI 网关的初始配置，严格按以下步骤执行：

【绝对禁止】不得向我索取 OpenAI、Anthropic、Gemini 或 OpenRouter 的 API Key，这四项全部由 Replit 平台通过 AI Integrations 自动提供。

${steps.join("\n\n")}

完成以上步骤后重启以下两个 Workflow，然后告知我：
- artifacts/api-server: API Server
- artifacts/api-portal: web`;
}

const STORAGE_PROMPT = `请帮我完成 AI 网关的云端存储初始化：

在 code_execution 工具中执行以下 JavaScript：

const result = await setupObjectStorage();
console.log(JSON.stringify(result));

执行成功后重启服务器，然后告知我。`;

let _id = 0;
const mkMsg = (from: Message["from"], text: string, extras: Partial<Omit<Message, "id" | "from" | "text">> = {}): Message =>
  ({ id: ++_id, from, text, ...extras });

function CopyBox({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(text).then(() => { setCopied(true); setTimeout(() => setCopied(false), 2000); }).catch(() => {});
  };
  return (
    <div style={{ background: "rgba(0,0,0,0.35)", border: "1px solid rgba(99,102,241,0.3)", borderRadius: "8px", padding: "10px 12px", display: "flex", alignItems: "center", gap: "10px", marginTop: "8px" }}>
      <span style={{ flex: 1, color: "#a5b4fc", fontSize: "12.5px", fontFamily: "Menlo, monospace", whiteSpace: "pre-wrap", wordBreak: "break-all", maxHeight: "140px", overflowY: "auto" }}>{text}</span>
      <button onClick={copy} style={{ padding: "5px 12px", borderRadius: "6px", border: `1px solid ${copied ? "rgba(74,222,128,0.5)" : "rgba(99,102,241,0.4)"}`, background: copied ? "rgba(74,222,128,0.12)" : "rgba(99,102,241,0.15)", color: copied ? "#4ade80" : "#a5b4fc", fontSize: "12px", fontWeight: 600, cursor: "pointer", flexShrink: 0 }}>
        {copied ? "✓" : "复制"}
      </button>
    </div>
  );
}

export default function SetupWizard({ baseUrl, onComplete, onDismiss }: Props) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [typing, setTyping] = useState(false);
  const [checking, setChecking] = useState(false);
  const [keyStep, setKeyStep] = useState(false);
  const [keyVal, setKeyVal] = useState("");
  const [chosenKey, setChosenKey] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  const addAgent = useCallback((text: string, extras: Partial<Omit<Message, "id" | "from" | "text">> = {}, delay = 600) => {
    setTyping(true);
    setTimeout(() => { setTyping(false); setMessages((p) => [...p, mkMsg("agent", text, extras)]); }, delay);
  }, []);

  const addUser = useCallback((text: string) => {
    setMessages((p) => [...p, mkMsg("user", text)]);
  }, []);

  const clearActions = useCallback(() => {
    setMessages((p) => p.map((m) => ({ ...m, actions: undefined })));
  }, []);

  useEffect(() => {
    setTimeout(() => {
      setMessages([mkMsg("agent", "你好！我是配置助手。\n\n这个 AI 网关内置了 OpenAI、Claude、Gemini 等所有模型。首次运行需要完成简单的初始化，全程通过 Replit Agent 完成，无需手动填写任何密钥。\n\n（我会自动检测已就绪的部分，只生成你真正需要的配置步骤）", {
        actions: [
          { label: "开始配置", value: "start", primary: true },
          { label: "已经配置好了", value: "already_done" },
        ],
      })]);
    }, 300);
  }, []);

  useEffect(() => {
    setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 80);
  }, [messages, typing]);

  const checkStatus = useCallback(async (): Promise<SetupStatus> => {
    try {
      const r = await fetch(`${baseUrl}/api/setup-status`, { signal: AbortSignal.timeout(8000) });
      if (!r.ok) return { configured: false, integrationsReady: false, storageReady: false };
      return await r.json() as SetupStatus;
    } catch { return { configured: false, integrationsReady: false, storageReady: false }; }
  }, [baseUrl]);

  const runCheck = useCallback(async () => {
    clearActions();
    setChecking(true);
    addUser("检测一下");
    addAgent("正在检测服务器配置状态…", {}, 300);
    const status = await checkStatus();
    setChecking(false);
    setMessages((p) => p.filter((m) => m.text !== "正在检测服务器配置状态…"));

    if (status.configured && status.integrationsReady && status.storageReady) {
      addAgent("配置成功！\n\n✓ 访问密码已设置\n✓ AI 集成已就绪\n✓ 云端存储已开通\n\n一切就绪，可以开始使用了。", { actions: [{ label: "完成，开始使用 🚀", value: "finish", primary: true }] }, 300);
    } else if (status.configured && status.integrationsReady && !status.storageReady) {
      addAgent("密码和 AI 集成都已就绪！\n\n还差最后一步：开通云端持久化存储（App Storage），确保子节点配置在 publish 后不会丢失。\n\n请将下方指令发给 Replit Agent：", { copyBlocks: [{ text: STORAGE_PROMPT }], actions: [{ label: "已重启，重新检测", value: "check", primary: true }] }, 300);
    } else if (chosenKey) {
      addAgent("配置还未完成。请将下方指令发给 Replit Agent，它会帮你完成剩余配置：", { copyBlocks: [{ text: buildConfigPrompt(chosenKey, { needIntegrations: !status.integrationsReady, needStorage: !status.storageReady }) }], actions: [{ label: "已重启，重新检测", value: "check", primary: true }] }, 300);
    } else {
      addAgent("配置还未完成，需要先设定一个访问密码：", {}, 300);
      setKeyStep(true);
    }
  }, [clearActions, addUser, addAgent, checkStatus, chosenKey]);

  const handleAction = useCallback(async (value: string, label: string) => {
    clearActions();
    if (value === "start") {
      addUser(label);
      addAgent("好的！首先请在下方设定一个访问密码。这个密码就是你之后在门户首页填写的 API Key，由你自己定义，例如 my-secret-123。", {});
      setKeyStep(true);
    } else if (value === "already_done") {
      addUser(label);
      addAgent("好的，我来检测服务器状态。", {}, 300);
      setTimeout(() => runCheck(), 900);
    } else if (value === "check") {
      await runCheck();
    } else if (value === "finish") {
      onComplete(chosenKey || undefined);
    }
  }, [clearActions, addUser, addAgent, runCheck, onComplete, chosenKey]);

  const handleKeySubmit = useCallback(async () => {
    const key = keyVal.trim();
    if (!key) return;
    setChosenKey(key);
    setKeyStep(false);
    setKeyVal("");
    addUser(`我的访问密码设定为：${"*".repeat(Math.max(0, key.length - 3))}${key.slice(-3)}`);
    const status = await checkStatus();
    const needIntegrations = !status.integrationsReady;
    const needStorage = !status.storageReady;
    const skipped: string[] = [];
    if (!needIntegrations) skipped.push("AI 集成");
    if (!needStorage) skipped.push("云端存储");
    const note = skipped.length ? `\n\n（已自动检测到${skipped.join("和")}就绪，已从指令中省略这些步骤）` : "";
    addAgent(`好！以下是完整配置指令，请复制发给 Replit Agent：${note}`, {
      copyBlocks: [{ text: buildConfigPrompt(key, { needIntegrations, needStorage }) }],
      actions: [{ label: "已重启，重新检测", value: "check", primary: true }],
    }, 600);
  }, [keyVal, addUser, addAgent, checkStatus]);

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.8)", zIndex: 1500, display: "flex", alignItems: "center", justifyContent: "center", padding: "24px", backdropFilter: "blur(8px)" }}>
      <div style={{ background: "hsl(222,47%,11%)", border: "1px solid rgba(99,102,241,0.3)", borderRadius: "20px", width: "100%", maxWidth: "580px", maxHeight: "80vh", display: "flex", flexDirection: "column", overflow: "hidden", boxShadow: "0 40px 100px rgba(0,0,0,0.8)" }}>

        {/* Header */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "18px 22px", borderBottom: "1px solid rgba(255,255,255,0.06)", flexShrink: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <div style={{ width: "34px", height: "34px", borderRadius: "10px", background: "linear-gradient(135deg,#6366f1,#8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "17px" }}>🚀</div>
            <div>
              <div style={{ fontSize: "15px", fontWeight: 700, color: "#f1f5f9" }}>配置向导</div>
              <div style={{ fontSize: "11px", color: "#475569" }}>AI 网关初始化助手</div>
            </div>
          </div>
          <button onClick={onDismiss} style={{ background: "none", border: "none", color: "#475569", cursor: "pointer", fontSize: "22px", lineHeight: 1 }}>×</button>
        </div>

        {/* Messages */}
        <div style={{ flex: 1, overflowY: "auto", padding: "18px 22px", display: "flex", flexDirection: "column", gap: "14px" }}>
          {messages.map((msg) => (
            <div key={msg.id} style={{ display: "flex", flexDirection: msg.from === "user" ? "row-reverse" : "row", gap: "10px", alignItems: "flex-start" }}>
              {msg.from === "agent" && (
                <div style={{ width: "28px", height: "28px", borderRadius: "50%", background: "linear-gradient(135deg,#6366f1,#8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "13px", flexShrink: 0 }}>🤖</div>
              )}
              <div style={{ maxWidth: "82%" }}>
                <div style={{ background: msg.from === "agent" ? "rgba(255,255,255,0.05)" : "rgba(99,102,241,0.2)", border: `1px solid ${msg.from === "agent" ? "rgba(255,255,255,0.08)" : "rgba(99,102,241,0.3)"}`, borderRadius: msg.from === "agent" ? "4px 14px 14px 14px" : "14px 4px 14px 14px", padding: "10px 14px", fontSize: "13px", color: "#cbd5e1", lineHeight: "1.65", whiteSpace: "pre-wrap" }}>
                  {msg.text}
                </div>
                {msg.copyBlocks?.map((cb, i) => <CopyBox key={i} text={cb.text} />)}
                {msg.actions && (
                  <div style={{ display: "flex", flexWrap: "wrap", gap: "6px", marginTop: "10px" }}>
                    {msg.actions.map((a) => (
                      <button key={a.value} onClick={() => handleAction(a.value, a.label)} disabled={checking}
                        style={{ padding: "7px 16px", borderRadius: "8px", border: `1px solid ${a.primary ? "rgba(99,102,241,0.5)" : "rgba(255,255,255,0.1)"}`, background: a.primary ? "rgba(99,102,241,0.25)" : "rgba(255,255,255,0.05)", color: a.primary ? "#a5b4fc" : "#94a3b8", fontSize: "13px", fontWeight: a.primary ? 600 : 400, cursor: checking ? "not-allowed" : "pointer", opacity: checking ? 0.5 : 1 }}>
                        {a.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
          {typing && (
            <div style={{ display: "flex", gap: "10px", alignItems: "flex-start" }}>
              <div style={{ width: "28px", height: "28px", borderRadius: "50%", background: "linear-gradient(135deg,#6366f1,#8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "13px", flexShrink: 0 }}>🤖</div>
              <div style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "4px 14px 14px 14px", padding: "12px 16px", display: "flex", gap: "5px" }}>
                {[0, 150, 300].map((delay) => (
                  <div key={delay} style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#6366f1", animation: `bounce 1.2s ${delay}ms ease-in-out infinite` }} />
                ))}
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Footer: key input or hint */}
        {keyStep ? (
          <div style={{ padding: "14px 22px", borderTop: "1px solid rgba(255,255,255,0.06)", flexShrink: 0 }}>
            <div style={{ display: "flex", gap: "8px" }}>
              <input
                autoFocus
                type="text"
                placeholder="输入你的访问密码，例如 my-secret-123"
                value={keyVal}
                onChange={(e) => setKeyVal(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") handleKeySubmit(); }}
                style={{ flex: 1, background: "rgba(0,0,0,0.3)", border: "1px solid rgba(99,102,241,0.35)", borderRadius: "8px", padding: "9px 13px", color: "#f1f5f9", fontSize: "13.5px", outline: "none", fontFamily: "Menlo, monospace" }}
              />
              <button onClick={handleKeySubmit} disabled={!keyVal.trim()} style={{ padding: "8px 16px", borderRadius: "8px", border: "1px solid rgba(99,102,241,0.5)", background: keyVal.trim() ? "rgba(99,102,241,0.25)" : "rgba(99,102,241,0.06)", color: keyVal.trim() ? "#a5b4fc" : "#334155", fontSize: "13px", fontWeight: 700, cursor: keyVal.trim() ? "pointer" : "not-allowed" }}>
                确认 →
              </button>
            </div>
          </div>
        ) : (
          <div style={{ padding: "10px 22px", borderTop: "1px solid rgba(255,255,255,0.04)", fontSize: "11px", color: "#1e293b", textAlign: "center", flexShrink: 0 }}>
            所有配置通过 Replit Agent 安全完成，密钥不会经过此页面
          </div>
        )}
      </div>
      <style>{`@keyframes bounce { 0%,80%,100% { transform:translateY(0);opacity:0.4; } 40% { transform:translateY(-5px);opacity:1; } }`}</style>
    </div>
  );
}
