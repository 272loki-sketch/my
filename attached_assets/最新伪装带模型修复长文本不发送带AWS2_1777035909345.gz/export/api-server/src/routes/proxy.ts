import { Router, type IRouter, type Request, type Response } from "express";
import OpenAI from "openai";
import Anthropic from "@anthropic-ai/sdk";
import { GoogleGenAI } from "@google/genai";
import { readJson, writeJson } from "../lib/cloudPersist";
import { getSillyTavernMode, loadSettings } from "./settings";

const router: IRouter = Router();

// ═══════════════════════════════════════════════════════════════════════════
// Model Registry
// ═══════════════════════════════════════════════════════════════════════════

type ProviderName = "openai" | "anthropic" | "gemini" | "openrouter";

const OPENAI_BASE_IDS = [
  "gpt-5.2", "gpt-5.1", "gpt-5", "gpt-5-mini", "gpt-5-nano",
  "gpt-4.1", "gpt-4.1-mini", "gpt-4.1-nano",
  "gpt-4o", "gpt-4o-mini",
  "o4-mini", "o3", "o3-mini",
];

const ANTHROPIC_BASE_IDS = [
  "claude-opus-4-6", "claude-opus-4-5", "claude-opus-4-1",
  "claude-sonnet-4-6", "claude-sonnet-4-5",
  "claude-haiku-4-5",
];

const GEMINI_BASE_IDS = [
  "gemini-3.1-pro-preview", "gemini-3-flash-preview",
  "gemini-2.5-pro", "gemini-2.5-flash",
];

const OPENROUTER_IDS = [
  "x-ai/grok-4.20", "x-ai/grok-4.1-fast", "x-ai/grok-4-fast",
  "meta-llama/llama-4-maverick", "meta-llama/llama-4-scout",
  "deepseek/deepseek-v3.2", "deepseek/deepseek-r1", "deepseek/deepseek-r1-0528",
  "mistralai/mistral-small-2603", "qwen/qwen3.5-122b-a10b",
  "google/gemini-2.5-pro",
  "anthropic/claude-opus-4.6",
  "cohere/command-a", "amazon/nova-premier-v1", "baidu/ernie-4.5-300b-a47b",
];

// These look like OpenRouter IDs but are actually aliases that route directly
// through Anthropic native API. The ".Xo" suffix is cosmetic for users;
// the real Anthropic model IDs are stored in ANTHROPIC_ALIAS_MAP below.
const ANTHROPIC_ALIAS_IDS = [
  "anthropic/claude-opus-4.5o",
  "anthropic/claude-opus-4.1o",
];

// AWS-Bedrock-forced variants — sent to OpenRouter with provider: { only: ["Bedrock"] }
// Model ID prefix "AWS/" is stripped and replaced with "anthropic/" at dispatch time.
const AWS_OPENROUTER_IDS = [
  "AWS/claude-opus-4.6",
  "AWS/claude-opus-4.5o",
  "AWS/claude-opus-4.1o",
];

// Build provider lookup map
const providerMap = new Map<string, ProviderName>();

for (const id of OPENAI_BASE_IDS) {
  providerMap.set(id, "openai");
  if (id.startsWith("o")) providerMap.set(`${id}-thinking`, "openai");
}
for (const id of ANTHROPIC_BASE_IDS) {
  providerMap.set(id, "anthropic");
  providerMap.set(`${id}-thinking`, "anthropic");
  providerMap.set(`${id}-thinking-visible`, "anthropic");
}
for (const id of GEMINI_BASE_IDS) {
  providerMap.set(id, "gemini");
  providerMap.set(`${id}-thinking`, "gemini");
  providerMap.set(`${id}-thinking-visible`, "gemini");
}
for (const id of OPENROUTER_IDS) {
  providerMap.set(id, "openrouter");
}
for (const id of AWS_OPENROUTER_IDS) {
  providerMap.set(id, "openrouter");
}
// Alias IDs route through Anthropic native API
for (const id of ANTHROPIC_ALIAS_IDS) {
  providerMap.set(id, "anthropic");
}

// Maps user-facing alias IDs → real Anthropic model IDs (direct Anthropic API)
const ANTHROPIC_ALIAS_MAP: Record<string, string> = {
  "anthropic/claude-opus-4.5o": "claude-opus-4-5",
  "anthropic/claude-opus-4.1o": "claude-opus-4-1",
};

// Maps AWS/* alias IDs → real model IDs passed to OpenRouter with Bedrock routing.
// OpenRouter Bedrock uses the same "anthropic/claude-XXX" naming as the regular
// anthropic route, so we map the ".Xo" cosmetic suffixes to the real model IDs.
const AWS_ALIAS_MAP: Record<string, string> = {
  "AWS/claude-opus-4.5o": "anthropic/claude-opus-4-5",
  "AWS/claude-opus-4.1o": "anthropic/claude-opus-4-1",
  // 4.6 keeps the original name — it already works on OpenRouter Bedrock as-is.
};

// All known model ids for the /v1/models listing
const ALL_MODEL_IDS: string[] = [
  ...OPENAI_BASE_IDS,
  ...OPENAI_BASE_IDS.filter((m) => m.startsWith("o")).map((m) => `${m}-thinking`),
  ...ANTHROPIC_BASE_IDS.flatMap((id) => [id, `${id}-thinking`, `${id}-thinking-visible`]),
  ...GEMINI_BASE_IDS.flatMap((id) => [id, `${id}-thinking`, `${id}-thinking-visible`]),
  ...OPENROUTER_IDS,
  ...AWS_OPENROUTER_IDS,
  ...ANTHROPIC_ALIAS_IDS,
];

function resolveProvider(model: string): ProviderName {
  const mapped = providerMap.get(model);
  if (mapped) return mapped;
  // OpenRouter routing for any model containing "/"
  if (model.includes("/")) return "openrouter";
  return "openai";
}

// ═══════════════════════════════════════════════════════════════════════════
// Disabled Models Management
// ═══════════════════════════════════════════════════════════════════════════

const MODELS_FILE = "disabled_models.json";
const disabledModelIds = new Set<string>();

async function loadDisabledModels(): Promise<void> {
  const saved = await readJson<string[]>(MODELS_FILE);
  if (Array.isArray(saved)) saved.forEach((id) => disabledModelIds.add(id));
}

async function saveDisabledModels(): Promise<void> {
  await writeJson(MODELS_FILE, Array.from(disabledModelIds));
}

export function isModelEnabled(id: string): boolean {
  return !disabledModelIds.has(id);
}

// ═══════════════════════════════════════════════════════════════════════════
// Routing Settings
// ═══════════════════════════════════════════════════════════════════════════

const ROUTING_FILE = "routing_settings.json";

interface RoutingConfig {
  localEnabled: boolean;
  localFallback: boolean;
  fakeStream: boolean;
}

let routingCfg: RoutingConfig = { localEnabled: true, localFallback: true, fakeStream: true };

async function loadRoutingConfig(): Promise<void> {
  const saved = await readJson<RoutingConfig>(ROUTING_FILE);
  if (saved) routingCfg = { ...routingCfg, ...saved };
}

async function saveRoutingConfig(): Promise<void> {
  await writeJson(ROUTING_FILE, routingCfg);
}

// ═══════════════════════════════════════════════════════════════════════════
// Dynamic Friend Backends
// ═══════════════════════════════════════════════════════════════════════════

const DYNAMIC_FILE = "dynamic_backends.json";

interface FriendNode { label: string; url: string; enabled?: boolean }

let friendNodes: FriendNode[] = [];

async function loadFriendNodes(): Promise<void> {
  const saved = await readJson<FriendNode[]>(DYNAMIC_FILE);
  if (Array.isArray(saved)) friendNodes = saved;
}

function saveFriendNodes(): void {
  writeJson(DYNAMIC_FILE, friendNodes).catch((e) => console.error("[persist] dynamic_backends:", e));
}

// Health cache: url → { healthy, ts }
const healthMap = new Map<string, { ok: boolean; ts: number }>();
const HEALTH_CACHE_TTL = 30_000;
const HEALTH_CHECK_TIMEOUT = 15_000;

function getCachedHealth(url: string): boolean | null {
  const e = healthMap.get(url);
  if (!e || Date.now() - e.ts > HEALTH_CACHE_TTL) return null;
  return e.ok;
}

function setNodeHealth(url: string, ok: boolean): void {
  healthMap.set(url, { ok, ts: Date.now() });
}

function getFriendApiKey(node: FriendNode): string {
  const raw = node.url;
  const parts = raw.split("|");
  return parts.length > 1 ? parts[1].trim() : (process.env.PROXY_API_KEY ?? "");
}

function getFriendUrl(node: FriendNode): string {
  return node.url.split("|")[0].trim();
}

function getActiveFriends(): Array<{ label: string; url: string; apiKey: string }> {
  return friendNodes
    .filter((n) => n.enabled !== false)
    .map((n) => ({ label: n.label, url: getFriendUrl(n), apiKey: getFriendApiKey(n) }))
    .filter(({ url }) => getCachedHealth(url) !== false);
}

// Background health probe
async function probeFriend(url: string): Promise<void> {
  try {
    const r = await fetch(`${url}/api/healthz`, { signal: AbortSignal.timeout(HEALTH_CHECK_TIMEOUT) });
    setNodeHealth(url, r.ok);
  } catch {
    setNodeHealth(url, false);
  }
}

setInterval(() => {
  for (const n of friendNodes.filter((n) => n.enabled !== false)) {
    void probeFriend(getFriendUrl(n));
  }
}, 30_000);

// Backend pool builder
type BackendRef =
  | { kind: "local" }
  | { kind: "friend"; label: string; url: string; apiKey: string };

function buildPool(): BackendRef[] {
  const friends = getActiveFriends();
  if (friends.length > 0) {
    return friends.map((f) => ({ kind: "friend" as const, ...f }));
  }
  if (routingCfg.localEnabled || routingCfg.localFallback) {
    return [{ kind: "local" }];
  }
  return [];
}

let reqCounter = 0;

function nextBackend(): BackendRef | null {
  const pool = buildPool();
  if (!pool.length) return null;
  return pool[reqCounter++ % pool.length];
}

function nextBackendExcluding(skip: Set<string>): BackendRef | null {
  const friends = getActiveFriends().filter((f) => !skip.has(f.url));
  if (friends.length > 0) {
    return { kind: "friend", ...friends[reqCounter++ % friends.length] };
  }
  if (routingCfg.localFallback && routingCfg.localEnabled) return { kind: "local" };
  return null;
}

// ═══════════════════════════════════════════════════════════════════════════
// Usage Statistics
// ═══════════════════════════════════════════════════════════════════════════

const STATS_FILE = "usage_stats.json";

interface NodeStat {
  calls: number;
  errors: number;
  promptTokens: number;
  completionTokens: number;
  totalMs: number;
  ttftMs: number;
  streamCalls: number;
}

const emptyNodeStat = (): NodeStat => ({
  calls: 0, errors: 0, promptTokens: 0, completionTokens: 0,
  totalMs: 0, ttftMs: 0, streamCalls: 0,
});

const statsDB = new Map<string, NodeStat>();

async function loadStats(): Promise<void> {
  const saved = await readJson<Record<string, NodeStat>>(STATS_FILE);
  if (saved) {
    for (const [label, raw] of Object.entries(saved)) {
      if (raw && typeof raw === "object") {
        statsDB.set(label, {
          calls: +raw.calls || 0, errors: +raw.errors || 0,
          promptTokens: +raw.promptTokens || 0, completionTokens: +raw.completionTokens || 0,
          totalMs: +raw.totalMs || 0, ttftMs: +raw.ttftMs || 0, streamCalls: +raw.streamCalls || 0,
        });
      }
    }
  }
}

async function flushStats(): Promise<void> {
  await writeJson(STATS_FILE, Object.fromEntries(statsDB.entries()));
}

let _flushTimer: ReturnType<typeof setTimeout> | null = null;
function scheduleFlush(): void {
  if (_flushTimer) clearTimeout(_flushTimer);
  _flushTimer = setTimeout(() => { _flushTimer = null; void flushStats(); }, 2_000);
}
setInterval(() => void flushStats(), 60_000);

for (const sig of ["SIGTERM", "SIGINT"] as const) {
  process.on(sig, () => {
    flushStats().finally(() => process.exit(0));
    setTimeout(() => process.exit(1), 3000);
  });
}

function statGet(label: string): NodeStat {
  if (!statsDB.has(label)) statsDB.set(label, emptyNodeStat());
  return statsDB.get(label)!;
}

function statRecord(label: string, opts: {
  promptTokens: number; completionTokens: number;
  durationMs: number; ttftMs?: number; streaming: boolean; error?: boolean;
}): void {
  const s = statGet(label);
  s.calls++;
  if (opts.error) s.errors++;
  s.promptTokens += opts.promptTokens;
  s.completionTokens += opts.completionTokens;
  s.totalMs += opts.durationMs;
  if (opts.ttftMs) s.ttftMs += opts.ttftMs;
  if (opts.streaming) s.streamCalls++;
  scheduleFlush();
}

// ═══════════════════════════════════════════════════════════════════════════
// Bootstrap: load all persisted data before serving requests
// ═══════════════════════════════════════════════════════════════════════════

export const gatewayReady: Promise<void> = (async () => {
  await Promise.all([loadSettings(), loadDisabledModels(), loadRoutingConfig(), loadFriendNodes(), loadStats()]);
  console.log(`[gateway] loaded ${statsDB.size} node stats, ${friendNodes.length} friend nodes, disabledModels=${disabledModelIds.size}`);
})();

// ═══════════════════════════════════════════════════════════════════════════
// Auth Middleware
// ═══════════════════════════════════════════════════════════════════════════

export function requireApiKey(req: Request, res: Response, next: () => void): void {
  const envKey = process.env.PROXY_API_KEY;
  if (!envKey) {
    res.status(500).json({ error: { message: "PROXY_API_KEY not configured on server", type: "server_error", code: "not_configured" } });
    return;
  }
  const auth = req.headers.authorization ?? "";
  const supplied: string =
    auth.startsWith("Bearer ") ? auth.slice(7).trim() :
    (req.headers["x-api-key"] as string | undefined) ??
    (req.headers["x-goog-api-key"] as string | undefined) ??
    (req.query["key"] as string | undefined) ?? "";
  if (supplied !== envKey) {
    res.status(401).json({ error: { message: "Invalid API key. Set your PROXY_API_KEY in Replit Secrets.", type: "auth_error", code: "invalid_key" } });
    return;
  }
  next();
}

// ═══════════════════════════════════════════════════════════════════════════
// AI Client Factories
// ═══════════════════════════════════════════════════════════════════════════

// 30-minute SDK timeout — long enough for ultra-long (150K-200K token) requests.
// The OpenAI and Anthropic SDKs default to 600 s; Replit's proxy can cut
// non-streaming sockets at ~10 min, but streaming keeps them alive indefinitely.
const LONG_TIMEOUT_MS = 30 * 60 * 1000; // 30 min

function createOpenAIClient(): OpenAI {
  const apiKey = process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
  const baseURL = process.env.AI_INTEGRATIONS_OPENAI_BASE_URL;
  if (!apiKey || !baseURL) throw new Error("OpenAI integration not configured. Add it via Tools → Integrations.");
  return new OpenAI({ apiKey, baseURL, timeout: LONG_TIMEOUT_MS });
}

function createAnthropicClient(): Anthropic {
  const apiKey = process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY;
  const baseURL = process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL;
  if (!apiKey || !baseURL) throw new Error("Anthropic integration not configured. Add it via Tools → Integrations.");
  return new Anthropic({ apiKey, baseURL, timeout: LONG_TIMEOUT_MS });
}

function createGeminiClient(): GoogleGenAI {
  const apiKey = process.env.AI_INTEGRATIONS_GEMINI_API_KEY;
  const baseUrl = process.env.AI_INTEGRATIONS_GEMINI_BASE_URL;
  if (!apiKey || !baseUrl) throw new Error("Gemini integration not configured. Add it via Tools → Integrations.");
  return new GoogleGenAI({ apiKey, httpOptions: { apiVersion: "", baseUrl, timeout: LONG_TIMEOUT_MS } });
}

function createOpenRouterClient(): OpenAI {
  const apiKey = process.env.AI_INTEGRATIONS_OPENROUTER_API_KEY;
  const baseURL = process.env.AI_INTEGRATIONS_OPENROUTER_BASE_URL;
  if (!apiKey || !baseURL) throw new Error("OpenRouter integration not configured. Add it via Tools → Integrations.");
  return new OpenAI({ apiKey, baseURL, timeout: LONG_TIMEOUT_MS });
}

// ═══════════════════════════════════════════════════════════════════════════
// SSE Helpers
// ═══════════════════════════════════════════════════════════════════════════

function sendSseHeaders(res: Response): void {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders();
}

function sseWrite(res: Response, data: string): void {
  res.write(data);
  if (typeof (res as { flush?: () => void }).flush === "function") {
    (res as { flush: () => void }).flush();
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// Type Definitions
// ═══════════════════════════════════════════════════════════════════════════

type MsgRole = "system" | "user" | "assistant" | "tool";

interface ContentPart {
  type: "text" | "image_url";
  text?: string;
  image_url?: { url: string };
}

interface ToolFn { name: string; description?: string; parameters?: unknown }
interface ToolDef { type: "function"; function: ToolFn }

interface ToolCallDelta { id: string; type: "function"; function: { name: string; arguments: string } }

interface ChatMsg {
  role: MsgRole;
  content: string | ContentPart[] | null;
  tool_calls?: ToolCallDelta[];
  tool_call_id?: string;
  name?: string;
}

type CallResult = { promptTokens: number; completionTokens: number; ttftMs?: number };

// ═══════════════════════════════════════════════════════════════════════════
// Fake Stream (convert JSON response → SSE chunks)
// ═══════════════════════════════════════════════════════════════════════════

async function fakeStream(res: Response, json: Record<string, unknown>, startTime: number): Promise<CallResult> {
  const choices = json["choices"] as Array<{ message?: { content?: string; tool_calls?: ToolCallDelta[] }; finish_reason?: string }> | undefined;
  const content = choices?.[0]?.message?.content ?? "";
  const finishReason = choices?.[0]?.finish_reason ?? "stop";
  const usage = json["usage"] as { prompt_tokens?: number; completion_tokens?: number } | null | undefined;
  const chatId = json["id"] ?? `chatcmpl-fake-${Date.now()}`;
  const modelName = json["model"] ?? "unknown";

  sendSseHeaders(res);
  const ttftMs = Date.now() - startTime;
  const words = content.match(/[\s\S]{1,4}/g) ?? [];

  for (let i = 0; i < words.length; i++) {
    const chunk = {
      id: chatId, object: "chat.completion.chunk", created: Math.floor(Date.now() / 1000), model: modelName,
      choices: [{ index: 0, delta: { role: i === 0 ? "assistant" : undefined, content: words[i] }, finish_reason: null }],
    };
    sseWrite(res, `data: ${JSON.stringify(chunk)}\n\n`);
    await new Promise<void>((r) => setTimeout(r, 12));
  }

  const doneChunk = {
    id: chatId, object: "chat.completion.chunk", created: Math.floor(Date.now() / 1000), model: modelName,
    choices: [{ index: 0, delta: {}, finish_reason: finishReason }],
    usage: { prompt_tokens: usage?.prompt_tokens ?? 0, completion_tokens: usage?.completion_tokens ?? 0, total_tokens: (usage?.prompt_tokens ?? 0) + (usage?.completion_tokens ?? 0) },
  };
  sseWrite(res, `data: ${JSON.stringify(doneChunk)}\n\n`);
  sseWrite(res, "data: [DONE]\n\n");
  res.end();

  return {
    promptTokens: usage?.prompt_tokens ?? Math.ceil(content.length / 4),
    completionTokens: usage?.completion_tokens ?? Math.ceil(content.length / 4),
    ttftMs,
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// OpenAI / OpenRouter Handler
// ═══════════════════════════════════════════════════════════════════════════

async function handleOpenAI(opts: {
  res: Response; client: OpenAI; model: string; messages: ChatMsg[];
  stream: boolean; maxTokens?: number; tools?: ToolDef[]; toolChoice?: unknown; startTime: number;
  extraBody?: Record<string, unknown>;
}): Promise<CallResult> {
  const { res, client, model, messages, stream, maxTokens, tools, toolChoice, startTime, extraBody } = opts;

  const params: Record<string, unknown> = {
    model,
    messages: messages as OpenAI.Chat.ChatCompletionMessageParam[],
    ...(maxTokens ? { max_tokens: maxTokens } : {}),
    ...(tools?.length ? { tools, tool_choice: toolChoice ?? "auto" } : {}),
    ...(extraBody ?? {}),
  };

  if (!stream) {
    const resp = await client.chat.completions.create({ ...params, stream: false } as OpenAI.Chat.ChatCompletionCreateParamsNonStreaming);
    res.json(resp);
    return {
      promptTokens: resp.usage?.prompt_tokens ?? 0,
      completionTokens: resp.usage?.completion_tokens ?? 0,
    };
  }

  sendSseHeaders(res);
  const keepalive = setInterval(() => sseWrite(res, ": ping\n\n"), 5_000);
  let promptTokens = 0, completionTokens = 0, ttftMs: number | undefined;

  try {
    const stream2 = await client.chat.completions.create({ ...params, stream: true, stream_options: { include_usage: true } } as OpenAI.Chat.ChatCompletionCreateParamsStreaming);
    try {
      for await (const chunk of stream2) {
        if (chunk.usage) {
          promptTokens = chunk.usage.prompt_tokens ?? promptTokens;
          completionTokens = chunk.usage.completion_tokens ?? completionTokens;
        }
        const delta = chunk.choices[0]?.delta?.content;
        if (delta && ttftMs === undefined) ttftMs = Date.now() - startTime;
        sseWrite(res, `data: ${JSON.stringify(chunk)}\n\n`);
      }
      sseWrite(res, "data: [DONE]\n\n");
    } catch (streamErr) {
      const errMsg = streamErr instanceof Error ? streamErr.message.slice(0, 300) : "Stream interrupted";
      try {
        if (ttftMs !== undefined) {
          const errChunk = { id: `chatcmpl-err-${Date.now()}`, object: "chat.completion.chunk", created: Math.floor(Date.now() / 1000), model: params.model as string, choices: [{ index: 0, delta: { content: `\n\n[Stream error: ${errMsg}]` }, finish_reason: "stop" }] };
          sseWrite(res, `data: ${JSON.stringify(errChunk)}\n\n`);
        }
        sseWrite(res, "data: [DONE]\n\n");
      } catch {}
      throw streamErr;
    }
  } finally {
    clearInterval(keepalive);
    res.end();
  }

  return { promptTokens, completionTokens, ttftMs };
}

// ═══════════════════════════════════════════════════════════════════════════
// Anthropic (Claude) Handler
// ═══════════════════════════════════════════════════════════════════════════

function oaiContentToClaude(content: string | ContentPart[] | null): Anthropic.ContentBlockParam[] | string {
  if (!content) return "";
  if (typeof content === "string") return content;
  return content.map((p) => {
    if (p.type === "image_url" && p.image_url) {
      const url = p.image_url.url;
      if (url.startsWith("data:")) {
        const [meta, b64] = url.split(",", 2);
        const mt = (meta.match(/data:([^;]+)/) ?? [])[1] ?? "image/jpeg";
        return { type: "image" as const, source: { type: "base64" as const, media_type: mt as "image/jpeg", data: b64 } };
      }
      return { type: "image" as const, source: { type: "url" as const, url } };
    }
    return { type: "text" as const, text: p.text ?? "" };
  });
}

function convertMessagesForClaude(messages: ChatMsg[]): {
  systemPrompt: string;
  claudeMessages: Anthropic.MessageParam[];
} {
  let systemPrompt = "";
  const claudeMessages: Anthropic.MessageParam[] = [];

  for (const msg of messages) {
    if (msg.role === "system") {
      systemPrompt += (systemPrompt ? "\n" : "") + (typeof msg.content === "string" ? msg.content : "");
      continue;
    }

    if (msg.role === "assistant") {
      if (msg.tool_calls?.length) {
        const parts: Anthropic.ContentBlockParam[] = [];
        const textContent = typeof msg.content === "string" ? msg.content : "";
        if (textContent) parts.push({ type: "text", text: textContent });
        for (const tc of msg.tool_calls) {
          let input: unknown = {};
          try { input = JSON.parse(tc.function.arguments); } catch {}
          parts.push({ type: "tool_use", id: tc.id, name: tc.function.name, input });
        }
        claudeMessages.push({ role: "assistant", content: parts });
      } else {
        claudeMessages.push({ role: "assistant", content: oaiContentToClaude(msg.content) });
      }
      continue;
    }

    if (msg.role === "tool") {
      claudeMessages.push({
        role: "user",
        content: [{ type: "tool_result", tool_use_id: msg.tool_call_id!, content: msg.content as string }],
      });
      continue;
    }

    // user role
    claudeMessages.push({ role: "user", content: oaiContentToClaude(msg.content) });
  }

  return { systemPrompt, claudeMessages };
}

function convertToolsForClaude(tools: ToolDef[]): Anthropic.Tool[] {
  return tools.map((t) => ({
    name: t.function.name,
    description: t.function.description ?? "",
    input_schema: (t.function.parameters ?? { type: "object", properties: {} }) as Anthropic.Tool["input_schema"],
  }));
}

const CLAUDE_MAX_TOKENS: Record<string, number> = {
  "claude-haiku-4-5": 8096,
  "claude-sonnet-4-5": 64000, "claude-sonnet-4-6": 64000,
  "claude-opus-4-1": 64000, "claude-opus-4-5": 64000, "claude-opus-4-6": 64000,
};

async function handleClaude(opts: {
  res: Response; client: Anthropic; model: string; messages: ChatMsg[];
  stream: boolean; maxTokens?: number; thinking: boolean; thinkingVisible: boolean;
  tools?: ToolDef[]; toolChoice?: unknown; startTime: number;
}): Promise<CallResult> {
  const { res, client, model, messages, stream, maxTokens, thinking, thinkingVisible, tools, toolChoice, startTime } = opts;

  const { systemPrompt, claudeMessages } = convertMessagesForClaude(messages);
  const modelMax = CLAUDE_MAX_TOKENS[model] ?? 64000;
  const effectiveMax = maxTokens ?? (thinking ? Math.max(modelMax, 32000) : modelMax);

  const params: Anthropic.Messages.MessageCreateParams = {
    model,
    messages: claudeMessages,
    max_tokens: effectiveMax,
    ...(systemPrompt ? { system: systemPrompt } : {}),
    ...(thinking ? { thinking: { type: "enabled", budget_tokens: Math.floor(effectiveMax * 0.8) } } : {}),
    ...(tools?.length ? { tools: convertToolsForClaude(tools), tool_choice: { type: "auto" } } : {}),
  };

  if (!stream) {
    // Always use streaming internally to avoid the Replit proxy's 10-minute non-stream timeout.
    // Accumulate the full response then return as a JSON (non-streaming) response.
    const textParts: string[] = [];
    const toolCallAccum: Array<{ id: string; name: string; arguments: string }> = [];
    let promptIn = 0, completionOut = 0;
    let finishReason = "stop";
    let resultId = `msg_${Date.now()}`;
    let thinkingBuf = "";
    let inThinkingBlock = false;
    let currentText = "";
    let toolCallIdx = -1;

    const streamResp = await client.messages.create({ ...params, stream: true });

    for await (const ev of streamResp) {
      if (ev.type === "message_start") {
        promptIn = ev.message?.usage?.input_tokens ?? 0;
        if (ev.message?.id) resultId = ev.message.id;
      } else if (ev.type === "content_block_start") {
        const block = ev.content_block;
        if (block.type === "thinking") {
          inThinkingBlock = true; thinkingBuf = "";
        } else if (block.type === "text") {
          currentText = "";
        } else if (block.type === "tool_use") {
          toolCallIdx++;
          toolCallAccum.push({ id: (block as { type: "tool_use"; id: string; name: string }).id, name: (block as { type: "tool_use"; id: string; name: string }).name, arguments: "" });
        }
      } else if (ev.type === "content_block_delta") {
        const delta = ev.delta;
        if (delta.type === "thinking_delta") {
          thinkingBuf += delta.thinking;
        } else if (delta.type === "text_delta") {
          currentText += delta.text;
        } else if (delta.type === "input_json_delta" && toolCallAccum[toolCallIdx]) {
          toolCallAccum[toolCallIdx].arguments += delta.partial_json;
        }
      } else if (ev.type === "content_block_stop") {
        if (inThinkingBlock) {
          if (thinkingVisible && thinkingBuf) textParts.push(`<thinking>\n${thinkingBuf}\n</thinking>`);
          inThinkingBlock = false; thinkingBuf = "";
        } else if (currentText) {
          textParts.push(currentText); currentText = "";
        }
      } else if (ev.type === "message_delta") {
        completionOut = ev.usage?.output_tokens ?? completionOut;
        finishReason = ev.delta?.stop_reason === "tool_use" ? "tool_calls" : (ev.delta?.stop_reason ?? "stop");
      }
    }
    if (currentText) textParts.push(currentText);

    const toolCalls: ToolCallDelta[] = toolCallAccum.map((tc) => ({
      id: tc.id, type: "function", function: { name: tc.name, arguments: tc.arguments },
    }));
    const text = textParts.join("\n\n");

    res.json({
      id: resultId, object: "chat.completion", created: Math.floor(Date.now() / 1000), model,
      choices: [{ index: 0, message: { role: "assistant", content: text || null, ...(toolCalls.length ? { tool_calls: toolCalls } : {}) }, finish_reason: finishReason }],
      usage: { prompt_tokens: promptIn, completion_tokens: completionOut, total_tokens: promptIn + completionOut },
    });
    return { promptTokens: promptIn, completionTokens: completionOut };
  }

  // Streaming
  sendSseHeaders(res);
  // 5s keepalive — prevents Replit proxy from killing idle SSE connections during
  // slow generation (e.g. large 150K+ token outputs where chunks arrive infrequently)
  const keepalive = setInterval(() => sseWrite(res, ": ping\n\n"), 5_000);
  let promptIn = 0, completionOut = 0, ttftMs: number | undefined;
  const chatId = `msg_${Date.now()}`;

  try {
    const streamResp = await client.messages.create({ ...params, stream: true });
    let thinkingBuf = "";
    let inThinking = false;
    let inText = false;
    let toolCallIdx = -1;
    const openedRoles = new Set<number>();

    try {
      for await (const ev of streamResp) {
        if (ev.type === "message_start") {
          promptIn = ev.message?.usage?.input_tokens ?? 0;
          const roleChunk = { id: chatId, object: "chat.completion.chunk", created: Math.floor(Date.now() / 1000), model, choices: [{ index: 0, delta: { role: "assistant", content: "" }, finish_reason: null }] };
          sseWrite(res, `data: ${JSON.stringify(roleChunk)}\n\n`);
        } else if (ev.type === "content_block_start") {
          const block = ev.content_block;
          if (block.type === "thinking") {
            inThinking = true; thinkingBuf = "";
            if (thinkingVisible) {
              const c = { id: chatId, object: "chat.completion.chunk", created: Math.floor(Date.now() / 1000), model, choices: [{ index: 0, delta: { content: "<thinking>\n" }, finish_reason: null }] };
              sseWrite(res, `data: ${JSON.stringify(c)}\n\n`);
            }
          } else if (block.type === "text") {
            inText = true;
          } else if (block.type === "tool_use") {
            toolCallIdx++;
            if (!openedRoles.has(0)) { openedRoles.add(0); }
            const c = { id: chatId, object: "chat.completion.chunk", created: Math.floor(Date.now() / 1000), model, choices: [{ index: 0, delta: { tool_calls: [{ index: toolCallIdx, id: (block as { type: "tool_use"; id: string; name: string }).id, type: "function", function: { name: (block as { type: "tool_use"; id: string; name: string }).name, arguments: "" } }] }, finish_reason: null }] };
            sseWrite(res, `data: ${JSON.stringify(c)}\n\n`);
          }
        } else if (ev.type === "content_block_delta") {
          const delta = ev.delta;
          if (delta.type === "thinking_delta") {
            thinkingBuf += delta.thinking;
            if (thinkingVisible) {
              const c = { id: chatId, object: "chat.completion.chunk", created: Math.floor(Date.now() / 1000), model, choices: [{ index: 0, delta: { content: delta.thinking }, finish_reason: null }] };
              sseWrite(res, `data: ${JSON.stringify(c)}\n\n`);
            }
          } else if (delta.type === "text_delta") {
            if (ttftMs === undefined) ttftMs = Date.now() - startTime;
            const c = { id: chatId, object: "chat.completion.chunk", created: Math.floor(Date.now() / 1000), model, choices: [{ index: 0, delta: { content: delta.text }, finish_reason: null }] };
            sseWrite(res, `data: ${JSON.stringify(c)}\n\n`);
          } else if (delta.type === "input_json_delta") {
            const c = { id: chatId, object: "chat.completion.chunk", created: Math.floor(Date.now() / 1000), model, choices: [{ index: 0, delta: { tool_calls: [{ index: toolCallIdx, function: { arguments: delta.partial_json } }] }, finish_reason: null }] };
            sseWrite(res, `data: ${JSON.stringify(c)}\n\n`);
          }
        } else if (ev.type === "content_block_stop") {
          if (inThinking && thinkingVisible) {
            const c = { id: chatId, object: "chat.completion.chunk", created: Math.floor(Date.now() / 1000), model, choices: [{ index: 0, delta: { content: "\n</thinking>\n\n" }, finish_reason: null }] };
            sseWrite(res, `data: ${JSON.stringify(c)}\n\n`);
          }
          inThinking = false; inText = false;
        } else if (ev.type === "message_delta") {
          completionOut = ev.usage?.output_tokens ?? completionOut;
          const finishReason = ev.delta?.stop_reason === "tool_use" ? "tool_calls" : (ev.delta?.stop_reason ?? "stop");
          const c = { id: chatId, object: "chat.completion.chunk", created: Math.floor(Date.now() / 1000), model, choices: [{ index: 0, delta: {}, finish_reason: finishReason }], usage: { prompt_tokens: promptIn, completion_tokens: completionOut, total_tokens: promptIn + completionOut } };
          sseWrite(res, `data: ${JSON.stringify(c)}\n\n`);
        }
      }
      sseWrite(res, "data: [DONE]\n\n");
    } catch (streamErr) {
      // Mid-stream upstream failure — send an error chunk so the client sees it
      // in-band, then close cleanly with [DONE] so clients don't hang waiting.
      const errMsg = streamErr instanceof Error ? streamErr.message.slice(0, 300) : "Stream interrupted by upstream";
      try {
        if (ttftMs !== undefined) {
          const errChunk = { id: chatId, object: "chat.completion.chunk", created: Math.floor(Date.now() / 1000), model, choices: [{ index: 0, delta: { content: `\n\n[Stream error: ${errMsg}]` }, finish_reason: "stop" }] };
          sseWrite(res, `data: ${JSON.stringify(errChunk)}\n\n`);
        }
        sseWrite(res, "data: [DONE]\n\n");
      } catch {}
      throw streamErr;
    }
  } finally {
    clearInterval(keepalive);
    res.end();
  }

  return { promptTokens: promptIn, completionTokens: completionOut, ttftMs };
}

// ═══════════════════════════════════════════════════════════════════════════
// Gemini Handler
// ═══════════════════════════════════════════════════════════════════════════

function oaiMessagesToGemini(messages: ChatMsg[]): {
  systemInstruction?: { parts: Array<{ text: string }> };
  contents: Array<{ role: string; parts: Array<{ text: string }> }>;
} {
  let systemInstruction: { parts: Array<{ text: string }> } | undefined;
  const contents: Array<{ role: string; parts: Array<{ text: string }> }> = [];

  for (const msg of messages) {
    if (msg.role === "system") {
      const text = typeof msg.content === "string" ? msg.content : "";
      systemInstruction = { parts: [{ text }] };
      continue;
    }
    const role = msg.role === "assistant" ? "model" : "user";
    const text = typeof msg.content === "string" ? msg.content
      : Array.isArray(msg.content) ? msg.content.filter((p) => p.type === "text").map((p) => p.text ?? "").join("") : "";
    contents.push({ role, parts: [{ text }] });
  }

  return { systemInstruction, contents };
}

function convertToolsForGemini(tools: ToolDef[]): unknown {
  return [{
    functionDeclarations: tools.map((t) => ({
      name: t.function.name,
      description: t.function.description ?? "",
      parameters: t.function.parameters ?? { type: "object", properties: {} },
    })),
  }];
}

async function handleGemini(opts: {
  res: Response; model: string; messages: ChatMsg[];
  stream: boolean; maxTokens?: number; thinking: boolean; startTime: number;
  tools?: ToolDef[];
}): Promise<CallResult> {
  const { res, model, messages, stream, maxTokens, thinking, startTime, tools } = opts;
  const client = createGeminiClient();
  const { systemInstruction, contents } = oaiMessagesToGemini(messages);

  const genConfig: Record<string, unknown> = {};
  if (maxTokens) genConfig["maxOutputTokens"] = maxTokens;
  if (thinking) genConfig["thinkingConfig"] = { thinkingBudget: maxTokens ? Math.floor(maxTokens * 0.8) : 8000 };

  const reqParams: Record<string, unknown> = {
    model,
    contents,
    config: genConfig,
    ...(systemInstruction ? { systemInstruction } : {}),
    ...(tools?.length ? { tools: convertToolsForGemini(tools) } : {}),
  };

  const chatId = `chatcmpl-gem-${Date.now()}`;

  if (!stream) {
    const result = await client.models.generateContent(reqParams as Parameters<typeof client.models.generateContent>[0]);
    const text = result.text ?? "";
    const usage = result.usageMetadata;
    res.json({
      id: chatId, object: "chat.completion", created: Math.floor(Date.now() / 1000), model,
      choices: [{ index: 0, message: { role: "assistant", content: text }, finish_reason: "stop" }],
      usage: { prompt_tokens: usage?.promptTokenCount ?? 0, completion_tokens: usage?.candidatesTokenCount ?? 0, total_tokens: usage?.totalTokenCount ?? 0 },
    });
    return { promptTokens: usage?.promptTokenCount ?? 0, completionTokens: usage?.candidatesTokenCount ?? 0 };
  }

  sendSseHeaders(res);
  const keepalive = setInterval(() => sseWrite(res, ": ping\n\n"), 15_000);
  let promptTokens = 0, completionTokens = 0, ttftMs: number | undefined;

  try {
    const streamResult = await client.models.generateContentStream(reqParams as Parameters<typeof client.models.generateContentStream>[0]);
    for await (const chunk of streamResult) {
      const text = chunk.text ?? "";
      if (text) {
        if (ttftMs === undefined) ttftMs = Date.now() - startTime;
        const c = {
          id: chatId, object: "chat.completion.chunk", created: Math.floor(Date.now() / 1000), model,
          choices: [{ index: 0, delta: { role: "assistant", content: text }, finish_reason: null }],
        };
        sseWrite(res, `data: ${JSON.stringify(c)}\n\n`);
      }
      const usage = chunk.usageMetadata;
      if (usage) {
        promptTokens = usage.promptTokenCount ?? promptTokens;
        completionTokens = usage.candidatesTokenCount ?? completionTokens;
      }
    }
    const doneChunk = {
      id: chatId, object: "chat.completion.chunk", created: Math.floor(Date.now() / 1000), model,
      choices: [{ index: 0, delta: {}, finish_reason: "stop" }],
      usage: { prompt_tokens: promptTokens, completion_tokens: completionTokens, total_tokens: promptTokens + completionTokens },
    };
    sseWrite(res, `data: ${JSON.stringify(doneChunk)}\n\n`);
    sseWrite(res, "data: [DONE]\n\n");
  } finally {
    clearInterval(keepalive);
    res.end();
  }

  return { promptTokens, completionTokens, ttftMs };
}

// ═══════════════════════════════════════════════════════════════════════════
// Friend Proxy Handler
// ═══════════════════════════════════════════════════════════════════════════

class FriendError extends Error {
  constructor(public httpStatus: number, msg: string) { super(msg); this.name = "FriendError"; }
}

async function handleFriendProxy(opts: {
  req: Request; res: Response;
  backend: { label: string; url: string; apiKey: string };
  model: string; messages: ChatMsg[]; stream: boolean; maxTokens?: number;
  tools?: ToolDef[]; toolChoice?: unknown; startTime: number;
}): Promise<CallResult> {
  const { res, backend, model, messages, stream, maxTokens, tools, toolChoice, startTime } = opts;

  const body: Record<string, unknown> = { model, messages, stream, max_tokens: maxTokens ?? 64000 };
  if (stream) body["stream_options"] = { include_usage: true };
  if (tools?.length) { body["tools"] = tools; body["tool_choice"] = toolChoice ?? "auto"; }

  if (!stream) {
    const r = await fetch(`${backend.url}/v1/chat/completions`, {
      method: "POST",
      headers: { Authorization: `Bearer ${backend.apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(LONG_TIMEOUT_MS),
    });
    if (!r.ok) {
      const errText = await r.text().catch(() => "unknown");
      throw new FriendError(r.status, `Friend ${r.status}: ${errText}`);
    }
    const json = await r.json() as Record<string, unknown>;
    res.json(json);
    const u = json["usage"] as { prompt_tokens?: number; completion_tokens?: number } | null | undefined;
    const inputChars = messages.reduce((acc, m) => acc + (typeof m.content === "string" ? m.content.length : 0), 0);
    return {
      promptTokens: u?.prompt_tokens ?? Math.ceil(inputChars / 4),
      completionTokens: u?.completion_tokens ?? 0,
    };
  }

  // streaming
  const r = await fetch(`${backend.url}/v1/chat/completions`, {
    method: "POST",
    headers: { Authorization: `Bearer ${backend.apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(LONG_TIMEOUT_MS),
  });
  if (!r.ok) {
    const errText = await r.text().catch(() => "unknown");
    throw new FriendError(r.status, `Friend ${r.status}: ${errText}`);
  }

  const ct = r.headers.get("content-type") ?? "";
  if (ct.includes("application/json") && routingCfg.fakeStream) {
    const json = await r.json() as Record<string, unknown>;
    return fakeStream(res, json, startTime);
  }

  sendSseHeaders(res);
  const keepalive = setInterval(() => sseWrite(res, ": ping\n\n"), 15_000);
  let promptTokens = 0, completionTokens = 0, ttftMs: number | undefined;
  let outputChars = 0;

  try {
    const reader = r.body!.getReader();
    const decoder = new TextDecoder();
    let buf = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      const lines = buf.split("\n");
      buf = lines.pop() ?? "";
      for (const line of lines) {
        const trimmed = line.trimEnd();
        if (!trimmed.startsWith("data:")) continue;
        const data = trimmed.slice(5).trim();
        if (data === "[DONE]") { sseWrite(res, "data: [DONE]\n\n"); continue; }
        try {
          const chunk = JSON.parse(data) as Record<string, unknown>;
          const usage = chunk["usage"] as { prompt_tokens?: number; completion_tokens?: number } | null | undefined;
          if (usage) { promptTokens = usage.prompt_tokens ?? promptTokens; completionTokens = usage.completion_tokens ?? completionTokens; }
          const delta = (chunk["choices"] as Array<{ delta?: { content?: string } }>)?.[0]?.delta?.content;
          if (delta) { if (ttftMs === undefined) ttftMs = Date.now() - startTime; outputChars += delta.length; }
          sseWrite(res, `data: ${JSON.stringify(chunk)}\n\n`);
        } catch {}
      }
    }
  } finally {
    clearInterval(keepalive);
    res.end();
  }

  if (promptTokens === 0) {
    const inputChars = messages.reduce((acc, m) => acc + (typeof m.content === "string" ? m.content.length : 0), 0);
    promptTokens = Math.ceil(inputChars / 4);
    completionTokens = Math.ceil(outputChars / 4);
  }
  return { promptTokens, completionTokens, ttftMs };
}

// ═══════════════════════════════════════════════════════════════════════════
// Core Proxy Dispatch
// ═══════════════════════════════════════════════════════════════════════════

async function dispatchRequest(opts: {
  req: Request; res: Response; model: string; messages: ChatMsg[];
  stream: boolean; maxTokens?: number; tools?: ToolDef[]; toolChoice?: unknown;
}): Promise<void> {
  const { req, res, model, messages, stream, maxTokens, tools, toolChoice } = opts;
  const startTime = Date.now();
  const provider = resolveProvider(model);

  const MAX_RETRIES = 3;
  const triedUrls = new Set<string>();
  let backend = nextBackend();

  if (!backend) {
    res.status(503).json({ error: { message: "No available backends — all sub-nodes are down and local is disabled", type: "service_unavailable" } });
    return;
  }

  for (let attempt = 0; ; attempt++) {
    const label = backend.kind === "local" ? "local" : backend.label;
    (req as Request & { log?: { info: (...a: unknown[]) => void } }).log?.info?.({ model, backend: label, attempt }, "proxy dispatch");

    try {
      let result: CallResult;

      if (backend.kind === "friend") {
        triedUrls.add(backend.url);
        result = await handleFriendProxy({ req, res, backend, model, messages, stream, maxTokens, tools, toolChoice, startTime });
        setNodeHealth(backend.url, true);
      } else if (provider === "anthropic") {
        // Resolve alias IDs (e.g. "anthropic/claude-opus-4.5o") → real Anthropic model ID
        const resolvedAlias = ANTHROPIC_ALIAS_MAP[model] ?? model;
        const baseModel = resolvedAlias.replace(/-thinking-visible$/, "").replace(/-thinking$/, "");
        const thinkingVisible = model.endsWith("-thinking-visible");
        const thinking = thinkingVisible || model.endsWith("-thinking");
        result = await handleClaude({ res, client: createAnthropicClient(), model: baseModel, messages, stream, maxTokens, thinking, thinkingVisible, tools, toolChoice, startTime });
      } else if (provider === "gemini") {
        const baseModel = model.replace(/-thinking-visible$/, "").replace(/-thinking$/, "");
        const thinking = model.endsWith("-thinking") || model.endsWith("-thinking-visible");
        result = await handleGemini({ res, model: baseModel, messages, stream, maxTokens, thinking, startTime, tools });
      } else if (provider === "openrouter") {
        if (model.startsWith("AWS/")) {
          // Resolve alias (e.g. AWS/claude-opus-4.5o → anthropic/claude-opus-4-5),
          // then force Bedrock routing via OpenRouter.
          // Fallback: strip "AWS/" → "anthropic/" for any unmapped AWS/ IDs.
          const orModel = AWS_ALIAS_MAP[model] ?? ("anthropic/" + model.slice(4));
          result = await handleOpenAI({ res, client: createOpenRouterClient(), model: orModel, messages, stream, maxTokens, tools, toolChoice, startTime, extraBody: { provider: { only: ["Bedrock"] } } });
        } else {
          result = await handleOpenAI({ res, client: createOpenRouterClient(), model, messages, stream, maxTokens, tools, toolChoice, startTime });
        }
      } else {
        result = await handleOpenAI({ res, client: createOpenAIClient(), model, messages, stream, maxTokens, tools, toolChoice, startTime });
      }

      statRecord(label, {
        promptTokens: result.promptTokens, completionTokens: result.completionTokens,
        durationMs: Date.now() - startTime, ttftMs: result.ttftMs, streaming: stream,
      });
      return;

    } catch (err) {
      const isFriendError = err instanceof FriendError;
      const is5xx = isFriendError && err.httpStatus >= 500;

      if (backend.kind === "friend" && (isFriendError ? is5xx : true)) {
        setNodeHealth(backend.url, false);
        if (attempt < MAX_RETRIES) {
          const next = nextBackendExcluding(triedUrls);
          if (next) { backend = next; continue; }
        }
      }

      statRecord(label, { promptTokens: 0, completionTokens: 0, durationMs: Date.now() - startTime, streaming: stream, error: true });

      if (!res.headersSent) {
        const msg = err instanceof Error ? err.message : "Proxy error";
        res.status(502).json({ error: { message: msg, type: "proxy_error" } });
      }
      return;
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// Routes: /v1/models, /v1/chat/completions, /v1/messages, Gemini native
// ═══════════════════════════════════════════════════════════════════════════

router.get("/v1/models", requireApiKey, (_req: Request, res: Response) => {
  const now = Math.floor(Date.now() / 1000);
  const data = ALL_MODEL_IDS.filter(isModelEnabled).map((id) => ({
    id, object: "model", created: now, owned_by: resolveProvider(id),
  }));
  res.json({ object: "list", data });
});

router.post("/v1/chat/completions", requireApiKey, async (req: Request, res: Response) => {
  const { model, messages, stream, max_tokens, tools, tool_choice } = req.body as {
    model?: string; messages: ChatMsg[]; stream?: boolean;
    max_tokens?: number; tools?: ToolDef[]; tool_choice?: unknown;
  };

  const resolvedModel = model && ALL_MODEL_IDS.includes(model) ? model : "gpt-4.1-mini";

  if (!isModelEnabled(resolvedModel)) {
    res.status(403).json({ error: { message: `Model '${resolvedModel}' is disabled`, type: "invalid_request_error", code: "model_disabled" } });
    return;
  }

  const provider = resolveProvider(resolvedModel);
  const isAnthropicModel = provider === "anthropic";

  const finalMessages = (isAnthropicModel && getSillyTavernMode() && !(tools?.length))
    ? [...messages, { role: "user" as const, content: "继续" }]
    : messages;

  await dispatchRequest({ req, res, model: resolvedModel, messages: finalMessages, stream: stream ?? false, maxTokens: max_tokens, tools, toolChoice: tool_choice });
});

router.post("/v1/messages", requireApiKey, async (req: Request, res: Response) => {
  const { model, messages, stream, max_tokens, system, tools } = req.body as {
    model?: string; messages: ChatMsg[]; stream?: boolean;
    max_tokens?: number; system?: string; tools?: ToolDef[];
  };

  const resolvedModel = model ?? "claude-sonnet-4-5";
  if (!isModelEnabled(resolvedModel)) {
    res.status(403).json({ error: { message: `Model '${resolvedModel}' is disabled`, type: "invalid_request_error" } });
    return;
  }

  const allMessages: ChatMsg[] = [
    ...(system ? [{ role: "system" as const, content: system }] : []),
    ...messages,
  ];

  const resolvedAlias = ANTHROPIC_ALIAS_MAP[resolvedModel] ?? resolvedModel;
  const baseModel = resolvedAlias.replace(/-thinking-visible$/, "").replace(/-thinking$/, "");
  const thinkingVisible = resolvedModel.endsWith("-thinking-visible");
  const thinking = thinkingVisible || resolvedModel.endsWith("-thinking");

  const client = createAnthropicClient();
  await handleClaude({ res, client, model: baseModel, messages: allMessages, stream: stream ?? false, maxTokens: max_tokens, thinking, thinkingVisible, tools, startTime: Date.now() });
});

router.post("/v1/models/:model\\:generateContent", requireApiKey, async (req: Request, res: Response) => {
  const model = req.params["model"];
  const { contents, generationConfig } = req.body as { contents: ChatMsg[]; generationConfig?: { maxOutputTokens?: number } };
  await handleGemini({ res, model, messages: contents, stream: false, maxTokens: generationConfig?.maxOutputTokens, thinking: false, startTime: Date.now() });
});

router.post("/v1/models/:model\\:streamGenerateContent", requireApiKey, async (req: Request, res: Response) => {
  const model = req.params["model"];
  const { contents, generationConfig } = req.body as { contents: ChatMsg[]; generationConfig?: { maxOutputTokens?: number } };
  await handleGemini({ res, model, messages: contents, stream: true, maxTokens: generationConfig?.maxOutputTokens, thinking: false, startTime: Date.now() });
});

// ═══════════════════════════════════════════════════════════════════════════
// Routes: /v1/stats
// ═══════════════════════════════════════════════════════════════════════════

router.get("/v1/stats", requireApiKey, (_req: Request, res: Response) => {
  const stats: Record<string, unknown> = {};

  // local node
  const localStat = statsDB.get("local") ?? emptyNodeStat();
  stats["local"] = {
    calls: localStat.calls, errors: localStat.errors,
    promptTokens: localStat.promptTokens, completionTokens: localStat.completionTokens,
    totalTokens: localStat.promptTokens + localStat.completionTokens,
    avgDurationMs: localStat.calls > 0 ? Math.round(localStat.totalMs / localStat.calls) : 0,
    avgTtftMs: localStat.streamCalls > 0 ? Math.round(localStat.ttftMs / localStat.streamCalls) : null,
    health: "healthy",
  };

  // friend nodes
  for (const node of friendNodes) {
    const url = getFriendUrl(node);
    const s = statsDB.get(node.label) ?? emptyNodeStat();
    const cached = healthMap.get(url);
    stats[node.label] = {
      calls: s.calls, errors: s.errors,
      promptTokens: s.promptTokens, completionTokens: s.completionTokens,
      totalTokens: s.promptTokens + s.completionTokens,
      avgDurationMs: s.calls > 0 ? Math.round(s.totalMs / s.calls) : 0,
      avgTtftMs: s.streamCalls > 0 ? Math.round(s.ttftMs / s.streamCalls) : null,
      health: cached ? (cached.ok ? "healthy" : "unhealthy") : "unknown",
      url,
      dynamic: true,
      enabled: node.enabled !== false,
    };
  }

  res.json({ stats, routing: routingCfg });
});

// ═══════════════════════════════════════════════════════════════════════════
// Routes: /v1/admin/backends
// ═══════════════════════════════════════════════════════════════════════════

router.get("/v1/admin/backends", requireApiKey, (_req: Request, res: Response) => {
  res.json({ backends: friendNodes });
});

router.post("/v1/admin/backends", requireApiKey, async (req: Request, res: Response) => {
  const { url, label } = req.body as { url?: string; label?: string };
  if (!url) { res.status(400).json({ error: "url is required" }); return; }

  const cleanUrl = url.replace(/\/+$/, "");
  const nodeLabel = label ?? `node_${Date.now()}`;

  if (friendNodes.some((n) => getFriendUrl(n) === cleanUrl)) {
    res.status(409).json({ error: "Backend already exists", label: friendNodes.find((n) => getFriendUrl(n) === cleanUrl)?.label });
    return;
  }

  // Health check
  let healthy = false;
  try {
    const r = await fetch(`${cleanUrl}/api/healthz`, { signal: AbortSignal.timeout(15000) });
    healthy = r.ok;
  } catch {}

  setNodeHealth(cleanUrl, healthy);
  friendNodes.push({ label: nodeLabel, url: cleanUrl, enabled: true });
  saveFriendNodes();
  res.json({ label: nodeLabel, url: cleanUrl, healthy });
});

router.delete("/v1/admin/backends/:label", requireApiKey, (req: Request, res: Response) => {
  const { label } = req.params;
  const idx = friendNodes.findIndex((n) => n.label === label);
  if (idx === -1) { res.status(404).json({ error: "Backend not found" }); return; }
  friendNodes.splice(idx, 1);
  saveFriendNodes();
  res.json({ ok: true });
});

router.patch("/v1/admin/backends/:label", requireApiKey, async (req: Request, res: Response) => {
  const { label } = req.params;
  const { enabled } = req.body as { enabled?: boolean };
  const node = friendNodes.find((n) => n.label === label);
  if (!node) { res.status(404).json({ error: "Backend not found" }); return; }
  if (typeof enabled === "boolean") node.enabled = enabled;
  saveFriendNodes();
  res.json({ ok: true, label: node.label, enabled: node.enabled });
});

router.patch("/v1/admin/backends", requireApiKey, async (req: Request, res: Response) => {
  const { labels, enabled } = req.body as { labels?: string[]; enabled?: boolean };
  if (!Array.isArray(labels) || typeof enabled !== "boolean") {
    res.status(400).json({ error: "labels (array) and enabled (boolean) required" }); return;
  }
  for (const n of friendNodes) { if (labels.includes(n.label)) n.enabled = enabled; }
  saveFriendNodes();
  res.json({ ok: true, updated: labels.length });
});

// ═══════════════════════════════════════════════════════════════════════════
// Routes: /v1/admin/routing
// ═══════════════════════════════════════════════════════════════════════════

router.patch("/v1/admin/routing", requireApiKey, async (req: Request, res: Response) => {
  const patch = req.body as Partial<RoutingConfig>;
  if (typeof patch.localEnabled === "boolean") routingCfg.localEnabled = patch.localEnabled;
  if (typeof patch.localFallback === "boolean") routingCfg.localFallback = patch.localFallback;
  if (typeof patch.fakeStream === "boolean") routingCfg.fakeStream = patch.fakeStream;
  await saveRoutingConfig();
  res.json({ ok: true, routing: routingCfg });
});

// ═══════════════════════════════════════════════════════════════════════════
// Routes: /v1/admin/models
// ═══════════════════════════════════════════════════════════════════════════

router.get("/v1/admin/models", requireApiKey, (_req: Request, res: Response) => {
  const models = ALL_MODEL_IDS.map((id) => ({
    id,
    provider: resolveProvider(id),
    enabled: isModelEnabled(id),
  }));

  const summary: Record<string, { total: number; enabled: number }> = {};
  for (const m of models) {
    if (!summary[m.provider]) summary[m.provider] = { total: 0, enabled: 0 };
    summary[m.provider].total++;
    if (m.enabled) summary[m.provider].enabled++;
  }

  res.json({ models, summary });
});

router.patch("/v1/admin/models", requireApiKey, async (req: Request, res: Response) => {
  const { ids, provider, enabled } = req.body as { ids?: string[]; provider?: string; enabled?: boolean };

  if (typeof enabled !== "boolean") { res.status(400).json({ error: "enabled required" }); return; }

  const targets: string[] = ids ?? (provider ? ALL_MODEL_IDS.filter((id) => resolveProvider(id) === provider) : []);
  for (const id of targets) {
    if (enabled) disabledModelIds.delete(id);
    else disabledModelIds.add(id);
  }

  await saveDisabledModels();
  res.json({ ok: true, updated: targets.length });
});

export default router;
