import { useState, useEffect, useCallback } from "react";
import SetupWizard from "./components/SetupWizard";
import UpdateBadge from "./components/UpdateBadge";

// ─── Model Registry ──────────────────────────────────────────────────────────

type ProviderKey = "openai" | "anthropic" | "gemini" | "openrouter";

interface ModelInfo {
  id: string;
  provider: ProviderKey;
  desc: string;
  badge?: "thinking" | "thinking-visible" | "tools" | "reasoning";
  context?: string;
}

const OPENAI_MODELS: ModelInfo[] = [
  { id: "gpt-5.2", provider: "openai", desc: "最新旗舰多模态模型", context: "128K", badge: "tools" },
  { id: "gpt-5.1", provider: "openai", desc: "旗舰多模态模型", context: "128K", badge: "tools" },
  { id: "gpt-5", provider: "openai", desc: "旗舰多模态模型", context: "128K", badge: "tools" },
  { id: "gpt-5-mini", provider: "openai", desc: "高性价比快速模型", context: "128K", badge: "tools" },
  { id: "gpt-5-nano", provider: "openai", desc: "超轻量边缘模型", context: "128K", badge: "tools" },
  { id: "gpt-4.1", provider: "openai", desc: "稳定通用旗舰模型", context: "1M", badge: "tools" },
  { id: "gpt-4.1-mini", provider: "openai", desc: "均衡速度与质量", context: "1M", badge: "tools" },
  { id: "gpt-4.1-nano", provider: "openai", desc: "超高速轻量模型", context: "1M", badge: "tools" },
  { id: "gpt-4o", provider: "openai", desc: "多模态旗舰（图文音）", context: "128K", badge: "tools" },
  { id: "gpt-4o-mini", provider: "openai", desc: "轻量多模态模型", context: "128K", badge: "tools" },
  { id: "o4-mini", provider: "openai", desc: "推理模型，快速高效", context: "200K", badge: "reasoning" },
  { id: "o4-mini-thinking", provider: "openai", desc: "o4 Mini 思考别名", context: "200K", badge: "thinking" },
  { id: "o3", provider: "openai", desc: "强推理旗舰模型", context: "200K", badge: "reasoning" },
  { id: "o3-thinking", provider: "openai", desc: "o3 思考别名", context: "200K", badge: "thinking" },
  { id: "o3-mini", provider: "openai", desc: "高效推理模型", context: "200K", badge: "reasoning" },
  { id: "o3-mini-thinking", provider: "openai", desc: "o3 Mini 思考别名", context: "200K", badge: "thinking" },
];

const ANTHROPIC_MODELS: ModelInfo[] = [
  { id: "claude-opus-4-6", provider: "anthropic", desc: "顶级推理与智能体任务", context: "200K", badge: "tools" },
  { id: "claude-opus-4-6-thinking", provider: "anthropic", desc: "扩展思考（隐藏）", context: "200K", badge: "thinking" },
  { id: "claude-opus-4-6-thinking-visible", provider: "anthropic", desc: "扩展思考（可见）", context: "200K", badge: "thinking-visible" },
  { id: "claude-opus-4-5", provider: "anthropic", desc: "旗舰推理模型", context: "200K", badge: "tools" },
  { id: "claude-opus-4-5-thinking", provider: "anthropic", desc: "扩展思考（隐藏）", context: "200K", badge: "thinking" },
  { id: "claude-opus-4-5-thinking-visible", provider: "anthropic", desc: "扩展思考（可见）", context: "200K", badge: "thinking-visible" },
  { id: "claude-opus-4-1", provider: "anthropic", desc: "旗舰模型（稳定版）", context: "200K", badge: "tools" },
  { id: "claude-opus-4-1-thinking", provider: "anthropic", desc: "扩展思考（隐藏）", context: "200K", badge: "thinking" },
  { id: "claude-opus-4-1-thinking-visible", provider: "anthropic", desc: "扩展思考（可见）", context: "200K", badge: "thinking-visible" },
  { id: "claude-sonnet-4-6", provider: "anthropic", desc: "均衡速度与质量", context: "200K", badge: "tools" },
  { id: "claude-sonnet-4-6-thinking", provider: "anthropic", desc: "扩展思考（隐藏）", context: "200K", badge: "thinking" },
  { id: "claude-sonnet-4-6-thinking-visible", provider: "anthropic", desc: "扩展思考（可见）", context: "200K", badge: "thinking-visible" },
  { id: "claude-sonnet-4-5", provider: "anthropic", desc: "均衡速度与质量（稳定）", context: "200K", badge: "tools" },
  { id: "claude-sonnet-4-5-thinking", provider: "anthropic", desc: "扩展思考（隐藏）", context: "200K", badge: "thinking" },
  { id: "claude-sonnet-4-5-thinking-visible", provider: "anthropic", desc: "扩展思考（可见）", context: "200K", badge: "thinking-visible" },
  { id: "claude-haiku-4-5", provider: "anthropic", desc: "轻量高速模型", context: "200K", badge: "tools" },
  { id: "claude-haiku-4-5-thinking", provider: "anthropic", desc: "扩展思考（隐藏）", context: "200K", badge: "thinking" },
  { id: "claude-haiku-4-5-thinking-visible", provider: "anthropic", desc: "扩展思考（可见）", context: "200K", badge: "thinking-visible" },
];

const GEMINI_MODELS: ModelInfo[] = [
  { id: "gemini-3.1-pro-preview", provider: "gemini", desc: "最新 Gemini 旗舰模型", context: "2M", badge: "tools" },
  { id: "gemini-3.1-pro-preview-thinking", provider: "gemini", desc: "扩展思考（隐藏）", context: "2M", badge: "thinking" },
  { id: "gemini-3.1-pro-preview-thinking-visible", provider: "gemini", desc: "扩展思考（可见）", context: "2M", badge: "thinking-visible" },
  { id: "gemini-3-flash-preview", provider: "gemini", desc: "快速 Gemini 3 模型", context: "1M", badge: "tools" },
  { id: "gemini-3-flash-preview-thinking", provider: "gemini", desc: "扩展思考（隐藏）", context: "1M", badge: "thinking" },
  { id: "gemini-3-flash-preview-thinking-visible", provider: "gemini", desc: "扩展思考（可见）", context: "1M", badge: "thinking-visible" },
  { id: "gemini-2.5-pro", provider: "gemini", desc: "旗舰推理模型（稳定）", context: "1M", badge: "tools" },
  { id: "gemini-2.5-pro-thinking", provider: "gemini", desc: "扩展思考（隐藏）", context: "1M", badge: "thinking" },
  { id: "gemini-2.5-pro-thinking-visible", provider: "gemini", desc: "扩展思考（可见）", context: "1M", badge: "thinking-visible" },
  { id: "gemini-2.5-flash", provider: "gemini", desc: "高性价比快速模型", context: "1M", badge: "tools" },
  { id: "gemini-2.5-flash-thinking", provider: "gemini", desc: "扩展思考（隐藏）", context: "1M", badge: "thinking" },
  { id: "gemini-2.5-flash-thinking-visible", provider: "gemini", desc: "扩展思考（可见）", context: "1M", badge: "thinking-visible" },
];

const OPENROUTER_MODELS: ModelInfo[] = [
  { id: "x-ai/grok-4.20", provider: "openrouter", desc: "xAI 旗舰推理模型", badge: "reasoning" },
  { id: "x-ai/grok-4.1-fast", provider: "openrouter", desc: "xAI 快速模型", badge: "tools" },
  { id: "x-ai/grok-4-fast", provider: "openrouter", desc: "xAI 旗舰快速模型", badge: "tools" },
  { id: "meta-llama/llama-4-maverick", provider: "openrouter", desc: "Meta Llama 4 旗舰", badge: "tools" },
  { id: "meta-llama/llama-4-scout", provider: "openrouter", desc: "Meta Llama 4 快速", badge: "tools" },
  { id: "deepseek/deepseek-v3.2", provider: "openrouter", desc: "DeepSeek 旗舰模型", badge: "tools" },
  { id: "deepseek/deepseek-r1", provider: "openrouter", desc: "DeepSeek 推理模型", badge: "reasoning" },
  { id: "deepseek/deepseek-r1-0528", provider: "openrouter", desc: "DeepSeek R1 最新版", badge: "reasoning" },
  { id: "mistralai/mistral-small-2603", provider: "openrouter", desc: "Mistral 快速模型", badge: "tools" },
  { id: "qwen/qwen3.5-122b-a10b", provider: "openrouter", desc: "阿里 Qwen 旗舰模型", badge: "tools" },
  { id: "google/gemini-2.5-pro", provider: "openrouter", desc: "Gemini via OpenRouter", badge: "tools" },
  { id: "anthropic/claude-opus-4.6", provider: "openrouter", desc: "Claude Opus 4.6 via OpenRouter", badge: "tools" },
  { id: "anthropic/claude-opus-4.5o", provider: "openrouter", desc: "Claude Opus 4.5o via OpenRouter", badge: "tools" },
  { id: "anthropic/claude-opus-4.1o", provider: "openrouter", desc: "Claude Opus 4.1o via OpenRouter", badge: "tools" },
  { id: "AWS/claude-opus-4.6", provider: "openrouter", desc: "Claude Opus 4.6 · 固定走 AWS Bedrock", badge: "tools" },
  { id: "AWS/claude-opus-4.5o", provider: "openrouter", desc: "Claude Opus 4.5o · 固定走 AWS Bedrock", badge: "tools" },
  { id: "AWS/claude-opus-4.1o", provider: "openrouter", desc: "Claude Opus 4.1o · 固定走 AWS Bedrock", badge: "tools" },
  { id: "cohere/command-a", provider: "openrouter", desc: "Cohere 企业级模型", badge: "tools" },
  { id: "amazon/nova-premier-v1", provider: "openrouter", desc: "Amazon Nova 旗舰", badge: "tools" },
  { id: "baidu/ernie-4.5-300b-a47b", provider: "openrouter", desc: "百度文心 MoE 模型", badge: "tools" },
];

const ALL_MODELS = [...OPENAI_MODELS, ...ANTHROPIC_MODELS, ...GEMINI_MODELS, ...OPENROUTER_MODELS];
const TOTAL_MODELS = ALL_MODELS.length;

// ─── Shared Components ────────────────────────────────────────────────────────

const PROVIDER_COLORS: Record<ProviderKey, { bg: string; border: string; text: string; dot: string }> = {
  openai:     { bg: "rgba(74,222,128,0.06)", border: "rgba(74,222,128,0.2)", text: "#4ade80", dot: "#4ade80" },
  anthropic:  { bg: "rgba(251,191,36,0.06)", border: "rgba(251,191,36,0.2)", text: "#fbbf24", dot: "#fbbf24" },
  gemini:     { bg: "rgba(96,165,250,0.06)", border: "rgba(96,165,250,0.2)", text: "#60a5fa", dot: "#60a5fa" },
  openrouter: { bg: "rgba(167,139,250,0.06)", border: "rgba(167,139,250,0.2)", text: "#a78bfa", dot: "#a78bfa" },
};

function Card({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "12px", padding: "18px 20px", ...style }}>
      {children}
    </div>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return <h3 style={{ margin: "0 0 14px", fontSize: "13px", fontWeight: 700, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.08em" }}>{children}</h3>;
}

function BadgeChip({ variant }: { variant: "thinking" | "thinking-visible" | "tools" | "reasoning" }) {
  const map: Record<string, { bg: string; color: string; label: string }> = {
    "thinking":         { bg: "rgba(139,92,246,0.15)", color: "#a78bfa", label: "思考" },
    "thinking-visible": { bg: "rgba(139,92,246,0.1)", color: "#c4b5fd", label: "思考可见" },
    "tools":            { bg: "rgba(34,211,238,0.1)", color: "#22d3ee", label: "工具调用" },
    "reasoning":        { bg: "rgba(251,191,36,0.1)", color: "#fbbf24", label: "推理" },
  };
  const s = map[variant];
  return <span style={{ fontSize: "10px", fontWeight: 600, background: s.bg, color: s.color, borderRadius: "4px", padding: "1px 6px" }}>{s.label}</span>;
}

function CopyBtn({ text, label = "复制" }: { text: string; label?: string }) {
  const [ok, setOk] = useState(false);
  const copy = async () => {
    try { await navigator.clipboard.writeText(text); } catch {
      const el = document.createElement("textarea");
      el.value = text;
      document.body.appendChild(el); el.select(); document.execCommand("copy"); document.body.removeChild(el);
    }
    setOk(true); setTimeout(() => setOk(false), 2000);
  };
  return (
    <button onClick={copy} style={{ padding: "6px 12px", borderRadius: "7px", border: `1px solid ${ok ? "rgba(74,222,128,0.4)" : "rgba(255,255,255,0.1)"}`, background: ok ? "rgba(74,222,128,0.1)" : "rgba(255,255,255,0.05)", color: ok ? "#4ade80" : "#64748b", fontSize: "12px", cursor: "pointer", flexShrink: 0, transition: "all 0.15s" }}>
      {ok ? "✓" : label}
    </button>
  );
}

function CodeBlock({ code, copyText }: { code: string; copyText?: string }) {
  return (
    <div style={{ position: "relative" }}>
      <pre style={{ background: "rgba(0,0,0,0.35)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "9px", padding: "14px 16px", paddingRight: "60px", fontFamily: "Menlo, monospace", fontSize: "12px", color: "#94a3b8", overflowX: "auto", whiteSpace: "pre-wrap", wordBreak: "break-all", margin: 0, lineHeight: 1.7 }}>
        {code}
      </pre>
      <div style={{ position: "absolute", top: "8px", right: "8px" }}>
        <CopyBtn text={copyText ?? code} />
      </div>
    </div>
  );
}

function MethodTag({ method }: { method: "GET" | "POST" | "DELETE" | "PATCH" }) {
  const c: Record<string, string> = { GET: "#4ade80", POST: "#60a5fa", DELETE: "#f87171", PATCH: "#fbbf24" };
  return <span style={{ fontSize: "11px", fontWeight: 700, color: c[method] ?? "#94a3b8", background: `${c[method] ?? "#94a3b8"}18`, borderRadius: "4px", padding: "2px 7px", flexShrink: 0, fontFamily: "Menlo, monospace" }}>{method}</span>;
}

function SwitchToggle({ on, onChange }: { on: boolean; onChange: () => void }) {
  return (
    <button onClick={onChange} style={{ width: "36px", height: "20px", borderRadius: "10px", border: "none", background: on ? "#6366f1" : "rgba(255,255,255,0.1)", cursor: "pointer", position: "relative", flexShrink: 0, transition: "background 0.2s" }}>
      <div style={{ position: "absolute", top: "2px", left: on ? "18px" : "2px", width: "16px", height: "16px", borderRadius: "50%", background: "#fff", transition: "left 0.2s" }} />
    </button>
  );
}

function normalizeApiUrl(raw: string): string {
  const url = raw.trim().replace(/\/+$/, "");
  if (!url) return url;
  return /\/api$/i.test(url) ? url : url + "/api";
}

// ─── Fleet Manager (Sub-node Management) ─────────────────────────────────────

interface FleetEntry {
  id: string; name: string; url: string; key: string;
  status: "unknown" | "checking" | "ok" | "updating" | "error" | "restarting";
  version: string | null; latestVersion: string | null;
  updateAvailable: boolean; lastChecked: number | null; updateLog: string | null;
}

const FLEET_STORE = "gateway_fleet_v1";

function fleetLoad(): FleetEntry[] {
  try { return JSON.parse(localStorage.getItem(FLEET_STORE) ?? "[]") as FleetEntry[]; } catch { return []; }
}

function fleetSave(data: FleetEntry[]) { localStorage.setItem(FLEET_STORE, JSON.stringify(data)); }

function uid() { return Math.random().toString(36).slice(2, 9); }

function FleetManager() {
  const [entries, setEntries] = useState<FleetEntry[]>(() => fleetLoad());
  const [formName, setFormName] = useState("");
  const [formUrl, setFormUrl] = useState("");
  const [formKey, setFormKey] = useState("");
  const [activeLog, setActiveLog] = useState<string | null>(null);

  const persist = (next: FleetEntry[]) => { setEntries(next); fleetSave(next); };
  const patchEntry = (id: string, p: Partial<FleetEntry>) => { const n = entries.map((e) => e.id === id ? { ...e, ...p } : e); persist(n); return n; };

  const addEntry = () => {
    const url = formUrl.trim().replace(/\/+$/, "");
    if (!url || !formKey.trim()) return;
    persist([...entries, { id: uid(), name: formName.trim() || url, url, key: formKey.trim(), status: "unknown", version: null, latestVersion: null, updateAvailable: false, lastChecked: null, updateLog: null }]);
    setFormName(""); setFormUrl(""); setFormKey("");
  };

  const checkEntry = async (id: string) => {
    const entry = entries.find((e) => e.id === id); if (!entry) return;
    patchEntry(id, { status: "checking" });
    try {
      const r = await fetch(`${entry.url}/api/update/version`, { headers: { Authorization: `Bearer ${entry.key}` }, signal: AbortSignal.timeout(10000) });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const d = await r.json() as { version?: string; hasUpdate?: boolean; latestVersion?: string };
      patchEntry(id, { status: "ok", version: d.version ?? null, latestVersion: d.latestVersion ?? null, updateAvailable: d.hasUpdate ?? false, lastChecked: Date.now() });
    } catch { patchEntry(id, { status: "error", lastChecked: Date.now() }); }
  };

  const updateEntry = async (id: string) => {
    const entry = entries.find((e) => e.id === id); if (!entry) return;
    patchEntry(id, { status: "updating", updateLog: null });
    try {
      const r = await fetch(`${entry.url}/api/update/apply`, { method: "POST", headers: { Authorization: `Bearer ${entry.key}`, "Content-Type": "application/json" }, signal: AbortSignal.timeout(60000) });
      const d = await r.json() as { message?: string };
      patchEntry(id, { status: r.ok ? "restarting" : "error", updateLog: d.message ?? "更新指令已发送", lastChecked: Date.now() });
      setActiveLog(id);
    } catch (err) { patchEntry(id, { status: "error", updateLog: `错误: ${(err as Error).message}`, lastChecked: Date.now() }); setActiveLog(id); }
  };

  const exportData = () => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([JSON.stringify(entries.map(({ name, url, key }) => ({ name, url, key })), null, 2)], { type: "application/json" }));
    a.download = "fleet.json"; a.click();
  };

  const importData = () => {
    const inp = document.createElement("input"); inp.type = "file"; inp.accept = ".json";
    inp.onchange = async (e) => {
      try {
        const file = (e.target as HTMLInputElement).files?.[0]; if (!file) return;
        const arr = JSON.parse(await file.text()) as Array<{ name?: string; url?: string; key?: string }>;
        const next = [...entries]; let added = 0;
        for (const item of arr) {
          if (!item.url || !item.key || next.some((x) => x.url === item.url)) continue;
          next.push({ id: uid(), name: item.name || item.url, url: item.url.replace(/\/+$/, ""), key: item.key, status: "unknown", version: null, latestVersion: null, updateAvailable: false, lastChecked: null, updateLog: null });
          added++;
        }
        persist(next); if (!added) alert("没有新节点被导入（URL 重复或格式错误）");
      } catch (err) { alert(`导入失败: ${(err as Error).message}`); }
    };
    inp.click();
  };

  const statusTag = (e: FleetEntry) => {
    if (e.status === "checking") return { label: "检测中", color: "#94a3b8" };
    if (e.status === "updating") return { label: "更新中", color: "#fbbf24" };
    if (e.status === "restarting") return { label: "重启中", color: "#818cf8" };
    if (e.status === "error") return { label: "连接失败", color: "#f87171" };
    if (e.status === "ok") return e.updateAvailable ? { label: `有新版本 v${e.latestVersion ?? ""}`, color: "#fbbf24" } : { label: "已是最新", color: "#4ade80" };
    return { label: "未检测", color: "#475569" };
  };

  const inp: React.CSSProperties = { background: "rgba(0,0,0,0.3)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "7px", padding: "7px 11px", color: "#e2e8f0", fontFamily: "Menlo, monospace", fontSize: "12.5px", outline: "none" };

  return (
    <Card>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "16px" }}>
        <SectionTitle>子节点管理</SectionTitle>
        <div style={{ display: "flex", gap: "6px" }}>
          <button onClick={importData} style={{ background: "none", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "6px", color: "#64748b", fontSize: "11px", padding: "4px 10px", cursor: "pointer" }}>导入</button>
          <button onClick={exportData} style={{ background: "none", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "6px", color: "#64748b", fontSize: "11px", padding: "4px 10px", cursor: "pointer" }}>导出</button>
          <button onClick={() => Promise.all(entries.map((e) => checkEntry(e.id)))} disabled={entries.length === 0} style={{ background: "none", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "6px", color: "#94a3b8", fontSize: "11px", padding: "4px 10px", cursor: "pointer" }}>全部检测</button>
          {entries.some((e) => e.updateAvailable) && (
            <button onClick={() => entries.filter((e) => e.updateAvailable).reduce((p, e) => p.then(() => updateEntry(e.id)), Promise.resolve())} style={{ background: "rgba(251,191,36,0.15)", border: "1px solid rgba(251,191,36,0.35)", borderRadius: "6px", color: "#fbbf24", fontSize: "11px", padding: "4px 10px", cursor: "pointer", fontWeight: 600 }}>全部更新</button>
          )}
        </div>
      </div>
      <p style={{ margin: "0 0 14px", fontSize: "12.5px", color: "#475569" }}>管理多个部署实例 · 数据保存在本地浏览器</p>
      <div style={{ display: "flex", gap: "6px", flexWrap: "wrap", marginBottom: "14px" }}>
        <input style={{ ...inp, flex: "0 0 110px" }} placeholder="名称" value={formName} onChange={(e) => setFormName(e.target.value)} />
        <input style={{ ...inp, flex: "2 1 180px" }} placeholder="https://your-proxy.replit.app（根地址）" value={formUrl} onChange={(e) => setFormUrl(e.target.value)} />
        <input type="password" style={{ ...inp, flex: "1 1 130px" }} placeholder="PROXY_API_KEY" value={formKey} onChange={(e) => setFormKey(e.target.value)} />
        <button onClick={addEntry} disabled={!formUrl || !formKey} style={{ background: (!formUrl || !formKey) ? "rgba(99,102,241,0.2)" : "rgba(99,102,241,0.7)", border: "1px solid rgba(99,102,241,0.6)", color: "#e0e7ff", borderRadius: "7px", padding: "7px 16px", fontSize: "13px", fontWeight: 600, cursor: (!formUrl || !formKey) ? "not-allowed" : "pointer", opacity: (!formUrl || !formKey) ? 0.5 : 1 }}>添加</button>
      </div>
      {entries.length === 0 ? (
        <div style={{ textAlign: "center", padding: "24px 0", color: "#334155", fontSize: "13px" }}>暂无节点，请在上方添加</div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
          {entries.map((e) => {
            const tag = statusTag(e);
            const busy = e.status === "checking" || e.status === "updating";
            return (
              <div key={e.id} style={{ background: "rgba(0,0,0,0.2)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: "9px", padding: "11px 14px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "10px", flexWrap: "wrap" }}>
                  <div style={{ width: "7px", height: "7px", borderRadius: "50%", background: tag.color, flexShrink: 0 }} />
                  <span style={{ fontSize: "13px", fontWeight: 600, color: "#cbd5e1", minWidth: "80px" }}>{e.name}</span>
                  <span style={{ fontSize: "11px", color: "#334155", fontFamily: "Menlo, monospace", flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: "240px" }}>{e.url}</span>
                  {e.version && <span style={{ fontSize: "11px", color: "#64748b", fontFamily: "Menlo, monospace" }}>v{e.version}</span>}
                  <span style={{ fontSize: "11px", fontWeight: 600, color: tag.color, background: `${tag.color}18`, borderRadius: "99px", padding: "2px 9px" }}>{tag.label}</span>
                  {e.lastChecked && <span style={{ fontSize: "10px", color: "#334155" }}>{new Date(e.lastChecked).toLocaleTimeString()}</span>}
                  <div style={{ display: "flex", gap: "5px", marginLeft: "auto" }}>
                    <button onClick={() => checkEntry(e.id)} disabled={busy} style={{ background: "none", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "5px", color: "#94a3b8", fontSize: "11px", padding: "3px 9px", cursor: busy ? "not-allowed" : "pointer", opacity: busy ? 0.4 : 1 }}>检测</button>
                    <button onClick={() => updateEntry(e.id)} disabled={busy} style={{ background: e.updateAvailable ? "rgba(251,191,36,0.12)" : "none", border: `1px solid ${e.updateAvailable ? "rgba(251,191,36,0.4)" : "rgba(255,255,255,0.1)"}`, borderRadius: "5px", color: e.updateAvailable ? "#fbbf24" : "#64748b", fontSize: "11px", padding: "3px 9px", cursor: busy ? "not-allowed" : "pointer", opacity: busy ? 0.4 : 1 }}>更新</button>
                    {e.updateLog && <button onClick={() => setActiveLog(activeLog === e.id ? null : e.id)} style={{ background: "none", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "5px", color: "#475569", fontSize: "11px", padding: "3px 9px", cursor: "pointer" }}>日志</button>}
                    <button onClick={() => persist(entries.filter((x) => x.id !== e.id))} style={{ background: "none", border: "1px solid rgba(248,113,113,0.3)", borderRadius: "5px", color: "#f87171", fontSize: "11px", padding: "3px 9px", cursor: "pointer" }}>删除</button>
                  </div>
                </div>
                {activeLog === e.id && e.updateLog && (
                  <div style={{ marginTop: "10px", background: "rgba(0,0,0,0.4)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: "6px", padding: "10px 14px", fontFamily: "Menlo, monospace", fontSize: "12px", color: "#4ade80", whiteSpace: "pre-wrap" }}>{e.updateLog}</div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </Card>
  );
}

// ─── Update Notification Bar ──────────────────────────────────────────────────

function UpdateBar({ baseUrl }: { baseUrl: string }) {
  const [hasUpdate, setHasUpdate] = useState(false);
  const [latestVer, setLatestVer] = useState("");
  const [notes, setNotes] = useState("");
  const [dismissed, setDismissed] = useState(false);
  const [copied, setCopied] = useState(false);
  const [busy, setBusy] = useState(false);

  const fetchVer = useCallback(async () => {
    try {
      const r = await fetch(`${baseUrl}/api/update/version`);
      if (!r.ok) return;
      const d = await r.json() as { hasUpdate?: boolean; latestVersion?: string; latestReleaseNotes?: string };
      setHasUpdate(!!d.hasUpdate); setLatestVer(d.latestVersion ?? ""); setNotes(d.latestReleaseNotes ?? "");
    } catch {}
  }, [baseUrl]);

  useEffect(() => { fetchVer(); const t = setInterval(fetchVer, 10 * 60 * 1000); return () => clearInterval(t); }, [fetchVer]);

  const prompt = (ver: string) =>
    `请帮我把 AI 网关更新到最新版本 ${ver}。\n从 GitHub 拉取最新代码，覆盖当前项目文件，然后运行 pnpm install，最后重启 "artifacts/api-server: API Server" 和 "artifacts/api-portal: web" 两个工作流。`;

  const doCopy = async () => {
    const text = prompt(latestVer);
    try { await navigator.clipboard.writeText(text); } catch {
      const el = document.createElement("textarea"); el.value = text;
      document.body.appendChild(el); el.select(); document.execCommand("copy"); document.body.removeChild(el);
    }
    setCopied(true); setTimeout(() => setCopied(false), 2500);
  };

  if (dismissed || !hasUpdate) return null;

  return (
    <div style={{ position: "sticky", top: 0, zIndex: 1000, background: "rgba(251,191,36,0.1)", borderBottom: "1px solid rgba(251,191,36,0.3)", backdropFilter: "blur(12px)" }}>
      <div style={{ maxWidth: "900px", margin: "0 auto", padding: "10px 24px", display: "flex", alignItems: "center", gap: "12px", flexWrap: "wrap" }}>
        <span>🎉</span>
        <div style={{ flex: 1 }}>
          <span style={{ fontSize: "13px", color: "#fbbf24" }}><strong>发现新版本 v{latestVer}</strong></span>
          {notes && <span style={{ color: "#92400e", marginLeft: "10px", fontSize: "12px" }}>{notes}</span>}
        </div>
        <button onClick={doCopy} style={{ padding: "5px 14px", borderRadius: "7px", fontSize: "12.5px", fontWeight: 700, border: `1px solid ${copied ? "rgba(74,222,128,0.5)" : "rgba(251,191,36,0.5)"}`, background: copied ? "rgba(74,222,128,0.15)" : "rgba(251,191,36,0.18)", color: copied ? "#4ade80" : "#fbbf24", cursor: "pointer" }}>
          {copied ? "✓ 已复制！" : "📋 复制更新提示词"}
        </button>
        <button onClick={async () => { setBusy(true); await fetchVer(); setBusy(false); }} disabled={busy} style={{ padding: "5px 10px", borderRadius: "7px", fontSize: "12px", border: "1px solid rgba(251,191,36,0.25)", background: "transparent", color: "#92400e", cursor: busy ? "not-allowed" : "pointer", opacity: busy ? 0.5 : 1 }}>
          {busy ? "检测中…" : "重新检测"}
        </button>
        <button onClick={() => setDismissed(true)} style={{ background: "none", border: "none", color: "#92400e", fontSize: "18px", cursor: "pointer", lineHeight: 1 }}>×</button>
      </div>
    </div>
  );
}

// ─── Page: Home ───────────────────────────────────────────────────────────────

function PageHome({ displayUrl, apiKey, setApiKey, sillyTavernMode, stLoading, onToggleSTMode }: {
  displayUrl: string; apiKey: string; setApiKey: (k: string) => void;
  sillyTavernMode: boolean; stLoading: boolean; onToggleSTMode: () => void;
}) {
  const releases = [
    { version: "v1.1.6", date: "2026-04-08", items: ["假流式支持：后端返回 JSON 时自动拆分为 SSE 流式输出", "假流式开关：路由策略面板新增独立开关并持久化", "持久化竞态修复：所有数据在接受请求前加载完成"] },
    { version: "v1.1.5", date: "2026-04-07", items: ["子节点优先路由：本地账号仅在所有子节点不可用时作为兜底", "健康检查超时提升到 15 秒（适应 Replit 冷启动）"] },
    { version: "v1.1.4", date: "2026-04-07", items: ["Gemini 和 OpenRouter 接入 Replit 内置 AI Integrations", "所有四个后端均无需任何第三方 API Key"] },
    { version: "v1.1.3", date: "2026-04-07", items: ["配置助手自动检测已就绪的部分，只生成需要的步骤"] },
  ];

  return (
    <>
      {/* Changelog */}
      <Card style={{ marginBottom: "14px" }}>
        <SectionTitle>更新日志</SectionTitle>
        {releases[0] && (
          <div style={{ marginBottom: "12px", paddingBottom: "12px", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
            <div style={{ display: "flex", gap: "10px", alignItems: "center", marginBottom: "8px" }}>
              <span style={{ fontFamily: "Menlo, monospace", fontSize: "13px", fontWeight: 700, color: "#a5b4fc" }}>{releases[0].version}</span>
              <span style={{ fontSize: "11px", color: "#334155" }}>{releases[0].date}</span>
            </div>
            {releases[0].items.map((item, i) => (
              <div key={i} style={{ display: "flex", gap: "8px", marginBottom: "3px" }}>
                <span style={{ color: "#4f46e5", flexShrink: 0, fontSize: "11px", marginTop: "2px" }}>▸</span>
                <div style={{ fontSize: "12.5px", color: "#94a3b8", lineHeight: 1.5 }}>{item}</div>
              </div>
            ))}
          </div>
        )}
        <div style={{ maxHeight: "180px", overflowY: "auto" }}>
          {releases.slice(1).map((r) => (
            <div key={r.version} style={{ marginBottom: "10px" }}>
              <div style={{ display: "flex", gap: "10px", alignItems: "center", marginBottom: "6px" }}>
                <span style={{ fontFamily: "Menlo, monospace", fontSize: "12px", fontWeight: 700, color: "#a5b4fc" }}>{r.version}</span>
                <span style={{ fontSize: "11px", color: "#334155" }}>{r.date}</span>
              </div>
              {r.items.map((item, i) => (
                <div key={i} style={{ display: "flex", gap: "8px", paddingLeft: "4px" }}>
                  <span style={{ color: "#4f46e5", flexShrink: 0, fontSize: "11px" }}>▸</span>
                  <div style={{ fontSize: "12px", color: "#475569", lineHeight: 1.5 }}>{item}</div>
                </div>
              ))}
            </div>
          ))}
        </div>
      </Card>

      {/* Feature Grid */}
      <div style={{ marginBottom: "14px" }}>
        <SectionTitle>核心功能</SectionTitle>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(240px,1fr))", gap: "10px" }}>
          {[
            { icon: "🔀", title: "多后端路由", desc: "按模型名称自动路由到 OpenAI / Anthropic / Gemini / OpenRouter。", color: "#6366f1" },
            { icon: "📐", title: "多格式兼容", desc: "支持 OpenAI、Claude Messages、Gemini Native 三种请求格式，自动转换。", color: "#3b82f6" },
            { icon: "🔧", title: "工具 / 函数调用", desc: "完整支持 OpenAI tools + tool_calls，自动转换到各后端原生格式。", color: "#f59e0b" },
            { icon: "🧠", title: "扩展思考模式", desc: "Claude / Gemini / o-series 均支持 -thinking 和 -thinking-visible 后缀别名。", color: "#a855f7" },
            { icon: "⚡", title: "流式输出 SSE", desc: "所有端点支持 SSE 流式，包含假流式兜底，防止空响应。", color: "#f43f5e" },
            { icon: "🔑", title: "多种认证方式", desc: "支持 Bearer Token / x-goog-api-key / ?key= 三种方式。", color: "#10b981" },
          ].map((f) => (
            <div key={f.title} style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "10px", padding: "16px", borderTopColor: `${f.color}30` }}>
              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "8px" }}>
                <span style={{ fontSize: "18px", width: "32px", height: "32px", background: `${f.color}15`, borderRadius: "8px", display: "flex", alignItems: "center", justifyContent: "center" }}>{f.icon}</span>
                <span style={{ fontWeight: 600, color: "#cbd5e1", fontSize: "13px" }}>{f.title}</span>
              </div>
              <p style={{ margin: 0, fontSize: "12.5px", color: "#475569", lineHeight: 1.6 }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Base URL */}
      <Card style={{ marginBottom: "14px" }}>
        <SectionTitle>Base URL</SectionTitle>
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <code style={{ flex: 1, background: "rgba(0,0,0,0.3)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "8px", padding: "10px 16px", fontFamily: "Menlo, monospace", fontSize: "14px", color: "#a78bfa", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{displayUrl}</code>
          <CopyBtn text={displayUrl} label="复制 URL" />
        </div>
        <p style={{ margin: "8px 0 0", fontSize: "12px", color: "#475569" }}>将此地址填入 OpenAI 兼容客户端（SillyTavern / Continue / Open WebUI / Cursor 等）的 Base URL 即可直接使用。</p>
      </Card>

      {/* API Key input */}
      <Card style={{ marginBottom: "14px" }}>
        <SectionTitle>API Key（用于统计和管理接口）</SectionTitle>
        <input
          type="password"
          placeholder="粘贴你在 Secrets 中设置的 PROXY_API_KEY"
          value={apiKey}
          onChange={(e) => { setApiKey(e.target.value); localStorage.setItem("proxy_api_key", e.target.value); }}
          style={{ width: "100%", boxSizing: "border-box", background: "rgba(0,0,0,0.3)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", padding: "10px 14px", color: "#e2e8f0", fontSize: "14px", outline: "none", fontFamily: "Menlo, monospace" }}
        />
        <p style={{ margin: "8px 0 0", fontSize: "12px", color: "#334155" }}>密钥仅保存在本地浏览器，用于访问统计和后端管理接口。</p>
      </Card>

      {/* SillyTavern Mode */}
      <Card style={{ marginBottom: "14px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <div style={{ fontSize: "13px", fontWeight: 600, color: "#cbd5e1", marginBottom: "4px" }}>SillyTavern 继续模式</div>
            <div style={{ fontSize: "12px", color: "#475569" }}>为所有 Claude 请求末尾自动追加 <code style={{ color: "#a78bfa", background: "rgba(167,139,250,0.1)", padding: "1px 5px", borderRadius: "4px" }}>继续</code> 消息，解决 SillyTavern 截断问题。</div>
          </div>
          {stLoading ? <span style={{ fontSize: "12px", color: "#334155" }}>加载中…</span> : <SwitchToggle on={sillyTavernMode} onChange={onToggleSTMode} />}
        </div>
      </Card>

      {/* Quick Start */}
      <Card>
        <SectionTitle>快速接入</SectionTitle>
        <div style={{ fontSize: "12px", color: "#64748b", marginBottom: "8px" }}>测试模型列表：</div>
        <CodeBlock code={`curl ${displayUrl}/v1/models \\\n  -H "Authorization: Bearer YOUR_PROXY_API_KEY"`} />
        <div style={{ fontSize: "12px", color: "#64748b", margin: "14px 0 8px" }}>流式对话测试：</div>
        <CodeBlock code={`curl ${displayUrl}/v1/chat/completions \\\n  -H "Authorization: Bearer YOUR_PROXY_API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '{"model":"gpt-4.1-mini","messages":[{"role":"user","content":"Hello!"}],"stream":true}'`} />
      </Card>
    </>
  );
}

// ─── Page: Stats & Nodes ─────────────────────────────────────────────────────

interface NodeStatData {
  calls: number; errors: number; promptTokens: number; completionTokens: number;
  totalTokens: number; avgDurationMs: number; avgTtftMs: number | null;
  health: string; url?: string; dynamic?: boolean; enabled?: boolean;
}

interface RoutingState { localEnabled: boolean; localFallback: boolean; fakeStream: boolean }

interface StatsPageProps {
  baseUrl: string; apiKey: string;
  stats: Record<string, NodeStatData> | null;
  statsError: false | "auth" | "server";
  onRefresh: () => void;
  addUrl: string; setAddUrl: (v: string) => void;
  addState: "idle" | "loading" | "ok" | "err"; addMsg: string;
  onAddBackend: (e: React.FormEvent) => void;
  onRemoveBackend: (l: string) => void;
  onToggleBackend: (l: string, en: boolean) => void;
  onBatchToggle: (labels: string[], en: boolean) => void;
  onBatchRemove: (labels: string[]) => void;
  routing: RoutingState;
  onToggleRouting: (field: keyof RoutingState, v: boolean) => void;
}

function PageStats(p: StatsPageProps) {
  const [sel, setSel] = useState<Set<string>>(new Set());
  const dynLabels = p.stats ? Object.entries(p.stats).filter(([, s]) => s.dynamic).map(([l]) => l) : [];
  const selDyn = dynLabels.filter((l) => sel.has(l));
  const toggleSel = (l: string) => setSel((prev) => { const s = new Set(prev); s.has(l) ? s.delete(l) : s.add(l); return s; });

  return (
    <>
      <Card style={{ marginBottom: "14px" }}>
        <SectionTitle>路由策略</SectionTitle>
        <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
          {([
            { field: "localEnabled" as const, label: "本地账号启用", desc: "是否将本地 AI Integrations 账号纳入路由池" },
            { field: "localFallback" as const, label: "本地账号兜底", desc: "所有子节点不可用时回落到本地账号" },
            { field: "fakeStream" as const, label: "假流式", desc: "子节点返回 JSON 时自动转换为 SSE 流式输出" },
          ]).map(({ field, label, desc }) => (
            <div key={field} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "12px" }}>
              <div>
                <div style={{ fontSize: "13px", color: "#cbd5e1", fontWeight: 500 }}>{label}</div>
                <div style={{ fontSize: "12px", color: "#475569" }}>{desc}</div>
              </div>
              <SwitchToggle on={p.routing[field]} onChange={() => p.onToggleRouting(field, !p.routing[field])} />
            </div>
          ))}
        </div>
      </Card>

      <Card style={{ marginBottom: "14px" }}>
        <SectionTitle>添加子节点</SectionTitle>
        <p style={{ margin: "0 0 12px", fontSize: "12.5px", color: "#475569", lineHeight: 1.6 }}>子节点必须是另一个部署了相同网关的实例。输入其根地址，系统会自动探测连通性。</p>
        <form onSubmit={p.onAddBackend} style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
          <input value={p.addUrl} onChange={(e) => p.setAddUrl(e.target.value)} placeholder="https://your-sub-node.replit.app（根地址）" style={{ flex: "1 1 300px", background: "rgba(0,0,0,0.3)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", padding: "9px 14px", color: "#e2e8f0", fontSize: "13px", outline: "none" }} />
          <button type="submit" disabled={p.addState === "loading" || !p.addUrl} style={{ padding: "9px 18px", borderRadius: "8px", border: "1px solid rgba(99,102,241,0.4)", background: p.addState === "ok" ? "rgba(74,222,128,0.15)" : "rgba(99,102,241,0.2)", color: p.addState === "ok" ? "#4ade80" : "#a5b4fc", fontSize: "13px", fontWeight: 600, cursor: (p.addState === "loading" || !p.addUrl) ? "not-allowed" : "pointer" }}>
            {p.addState === "loading" ? "添加中…" : p.addState === "ok" ? "✓ 已添加" : "添加"}
          </button>
        </form>
        {p.addMsg && <div style={{ marginTop: "8px", fontSize: "12px", color: p.addState === "ok" ? "#4ade80" : "#f87171" }}>{p.addMsg}</div>}
      </Card>

      <Card style={{ marginBottom: "14px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "16px" }}>
          <SectionTitle>用量统计</SectionTitle>
          <button onClick={p.onRefresh} style={{ padding: "6px 14px", borderRadius: "7px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.05)", color: "#475569", fontSize: "12px", cursor: "pointer" }}>刷新</button>
        </div>

        {!p.apiKey && <div style={{ textAlign: "center", padding: "24px", color: "#334155", fontSize: "13px" }}>请在首页填写 API Key 后查看统计</div>}
        {p.apiKey && p.statsError === "auth" && <div style={{ background: "rgba(248,113,113,0.1)", border: "1px solid rgba(248,113,113,0.25)", borderRadius: "8px", padding: "12px 16px", fontSize: "13px", color: "#f87171" }}>API Key 不正确，请在首页检查 PROXY_API_KEY。</div>}
        {p.apiKey && p.statsError === "server" && <div style={{ background: "rgba(251,191,36,0.1)", border: "1px solid rgba(251,191,36,0.25)", borderRadius: "8px", padding: "12px 16px", fontSize: "13px", color: "#fbbf24" }}>服务器未配置 PROXY_API_KEY，请通过配置向导完成初始化。</div>}

        {p.stats && !p.statsError && (
          <>
            <div style={{ display: "flex", gap: "12px", flexWrap: "wrap", marginBottom: "14px" }}>
              {[
                { label: "总请求", value: Object.values(p.stats).reduce((a, s) => a + s.calls, 0).toLocaleString() },
                { label: "总 Token", value: `${(Object.values(p.stats).reduce((a, s) => a + s.totalTokens, 0) / 1000).toFixed(1)}K` },
                { label: "活跃节点", value: Object.values(p.stats).filter((s) => s.calls > 0).length },
                { label: "错误次数", value: Object.values(p.stats).reduce((a, s) => a + s.errors, 0), warn: true },
              ].map(({ label, value, warn }) => (
                <div key={label} style={{ background: "rgba(0,0,0,0.2)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: "8px", padding: "10px 16px", flex: "1 1 100px" }}>
                  <div style={{ fontSize: "11px", color: "#475569", marginBottom: "4px" }}>{label}</div>
                  <div style={{ fontSize: "20px", fontWeight: 700, color: (warn && Number(value) > 0) ? "#f87171" : "#f1f5f9", fontFamily: "Menlo, monospace" }}>{value}</div>
                </div>
              ))}
            </div>

            {selDyn.length > 0 && (
              <div style={{ display: "flex", gap: "6px", marginBottom: "10px", flexWrap: "wrap", alignItems: "center" }}>
                <span style={{ fontSize: "12px", color: "#475569" }}>已选 {selDyn.length} 个节点：</span>
                <button onClick={() => { p.onBatchToggle(selDyn, true); setSel(new Set()); }} style={{ padding: "4px 10px", borderRadius: "6px", border: "1px solid rgba(74,222,128,0.3)", background: "rgba(74,222,128,0.08)", color: "#4ade80", fontSize: "11px", cursor: "pointer" }}>启用</button>
                <button onClick={() => { p.onBatchToggle(selDyn, false); setSel(new Set()); }} style={{ padding: "4px 10px", borderRadius: "6px", border: "1px solid rgba(248,113,113,0.3)", background: "rgba(248,113,113,0.08)", color: "#f87171", fontSize: "11px", cursor: "pointer" }}>禁用</button>
                <button onClick={() => { p.onBatchRemove(selDyn); setSel(new Set()); }} style={{ padding: "4px 10px", borderRadius: "6px", border: "1px solid rgba(248,113,113,0.3)", background: "rgba(248,113,113,0.08)", color: "#f87171", fontSize: "11px", cursor: "pointer" }}>删除</button>
              </div>
            )}

            <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
              {Object.entries(p.stats).map(([label, s]) => {
                const enabled = s.enabled !== false;
                const healthy = s.health === "healthy";
                return (
                  <div key={label} style={{ background: enabled ? "rgba(0,0,0,0.2)" : "rgba(0,0,0,0.35)", border: `1px solid ${enabled ? "rgba(255,255,255,0.06)" : "rgba(248,113,113,0.15)"}`, borderRadius: "8px", padding: "12px 14px", opacity: enabled ? 1 : 0.65 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "8px", flexWrap: "wrap" }}>
                      {s.dynamic && <input type="checkbox" checked={sel.has(label)} onChange={() => toggleSel(label)} style={{ cursor: "pointer" }} />}
                      <div style={{ width: "7px", height: "7px", borderRadius: "50%", background: !enabled ? "#64748b" : healthy ? "#4ade80" : "#f87171", boxShadow: (enabled && healthy) ? "0 0 5px #4ade80" : undefined, flexShrink: 0 }} />
                      <span style={{ fontSize: "13px", fontWeight: 600, color: enabled ? "#94a3b8" : "#475569", fontFamily: "Menlo, monospace" }}>{label}</span>
                      {s.dynamic && <span style={{ fontSize: "10px", color: "#a78bfa", background: "rgba(167,139,250,0.15)", border: "1px solid rgba(167,139,250,0.3)", borderRadius: "4px", padding: "1px 5px" }}>动态</span>}
                      {!enabled && <span style={{ fontSize: "10px", color: "#f87171", background: "rgba(248,113,113,0.1)", borderRadius: "4px", padding: "1px 5px" }}>已禁用</span>}
                      {s.url && <span style={{ fontSize: "11px", color: "#334155", fontFamily: "Menlo, monospace", flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{s.url}</span>}
                      {s.dynamic && (
                        <div style={{ display: "flex", gap: "5px", marginLeft: "auto" }}>
                          <button onClick={() => p.onToggleBackend(label, !enabled)} style={{ padding: "3px 8px", borderRadius: "5px", border: `1px solid ${enabled ? "rgba(248,113,113,0.3)" : "rgba(74,222,128,0.3)"}`, background: "none", color: enabled ? "#f87171" : "#4ade80", fontSize: "11px", cursor: "pointer" }}>{enabled ? "禁用" : "启用"}</button>
                          <button onClick={() => p.onRemoveBackend(label)} style={{ padding: "3px 8px", borderRadius: "5px", border: "1px solid rgba(248,113,113,0.3)", background: "none", color: "#f87171", fontSize: "11px", cursor: "pointer" }}>删除</button>
                        </div>
                      )}
                    </div>
                    <div style={{ display: "flex", gap: "16px", flexWrap: "wrap" }}>
                      {[
                        { l: "请求", v: s.calls },
                        { l: "错误", v: s.errors, red: s.errors > 0 },
                        { l: "Prompt", v: `${(s.promptTokens / 1000).toFixed(1)}K` },
                        { l: "输出", v: `${(s.completionTokens / 1000).toFixed(1)}K` },
                        { l: "总 Token", v: `${(s.totalTokens / 1000).toFixed(1)}K` },
                        { l: "均耗时", v: `${s.avgDurationMs}ms` },
                        ...(s.avgTtftMs ? [{ l: "首 Token", v: `${s.avgTtftMs}ms` }] : []),
                      ].map(({ l, v, red }) => (
                        <div key={l}>
                          <div style={{ fontSize: "10px", color: "#475569" }}>{l}</div>
                          <div style={{ fontSize: "13px", fontWeight: 600, color: (red as boolean | undefined) ? "#f87171" : "#cbd5e1", fontFamily: "Menlo, monospace" }}>{v}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}
      </Card>

      <FleetManager />
    </>
  );
}

// ─── Page: Models ─────────────────────────────────────────────────────────────

interface ModelRecord { id: string; provider: ProviderKey; enabled: boolean }
interface GroupCount { total: number; enabled: number }

function PageModels({ apiKey, modelStatus, summary, onRefresh, onToggleProvider, onToggleModel }: {
  apiKey: string; modelStatus: ModelRecord[]; summary: Record<string, GroupCount>;
  onRefresh: () => void; onToggleProvider: (p: string, en: boolean) => void; onToggleModel: (id: string, en: boolean) => void;
}) {
  const [filter, setFilter] = useState<"all" | "enabled" | "disabled">("all");
  const [exp, setExp] = useState<Record<string, boolean>>({ openai: false, anthropic: false, gemini: false, openrouter: false });

  const statusMap = new Map(modelStatus.map((m) => [m.id, m.enabled]));

  const groups: Array<{ key: ProviderKey; title: string; models: ModelInfo[] }> = [
    { key: "openai", title: "OpenAI", models: OPENAI_MODELS },
    { key: "anthropic", title: "Anthropic Claude", models: ANTHROPIC_MODELS },
    { key: "gemini", title: "Google Gemini", models: GEMINI_MODELS },
    { key: "openrouter", title: "OpenRouter", models: OPENROUTER_MODELS },
  ];

  if (!apiKey) return <Card><div style={{ textAlign: "center", padding: "32px", color: "#334155", fontSize: "13px" }}>请在首页填写 API Key 后管理模型</div></Card>;

  return (
    <>
      <Card style={{ marginBottom: "12px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", gap: "6px" }}>
            {(["all", "enabled", "disabled"] as const).map((f) => (
              <button key={f} onClick={() => setFilter(f)} style={{ padding: "5px 12px", borderRadius: "6px", border: "1px solid rgba(255,255,255,0.08)", background: filter === f ? "rgba(99,102,241,0.2)" : "transparent", color: filter === f ? "#a5b4fc" : "#475569", fontSize: "12px", cursor: "pointer", fontWeight: filter === f ? 600 : 400 }}>
                {f === "all" ? "全部" : f === "enabled" ? "已启用" : "已禁用"}
              </button>
            ))}
          </div>
          <button onClick={onRefresh} style={{ padding: "6px 14px", borderRadius: "7px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.05)", color: "#475569", fontSize: "12px", cursor: "pointer" }}>刷新</button>
        </div>
      </Card>

      {groups.map(({ key, title, models }) => {
        const c = PROVIDER_COLORS[key];
        const grp = summary[key] ?? { total: models.length, enabled: models.length };
        const isExp = exp[key];
        const filtered = models.filter((m) => {
          const en = statusMap.get(m.id) ?? true;
          return filter === "enabled" ? en : filter === "disabled" ? !en : true;
        });

        return (
          <div key={key} style={{ marginBottom: "8px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "10px", background: c.bg, border: `1px solid ${c.border}`, borderRadius: "8px", padding: "10px 14px" }}>
              <div style={{ width: "8px", height: "8px", borderRadius: "50%", background: c.dot, flexShrink: 0 }} />
              <button onClick={() => setExp((prev) => ({ ...prev, [key]: !prev[key] }))} style={{ background: "none", border: "none", cursor: "pointer", fontWeight: 600, color: c.text, fontSize: "13px", flex: 1, textAlign: "left", padding: 0 }}>{title}</button>
              <span style={{ fontSize: "12px", color: "#475569" }}>{grp.enabled}/{grp.total} 已启用</span>
              <button onClick={() => onToggleProvider(key, true)} style={{ padding: "3px 10px", borderRadius: "5px", fontSize: "11px", border: "1px solid rgba(74,222,128,0.3)", background: "rgba(74,222,128,0.08)", color: "#4ade80", cursor: "pointer" }}>全部启用</button>
              <button onClick={() => onToggleProvider(key, false)} style={{ padding: "3px 10px", borderRadius: "5px", fontSize: "11px", border: "1px solid rgba(248,113,113,0.3)", background: "rgba(248,113,113,0.08)", color: "#f87171", cursor: "pointer" }}>全部禁用</button>
              <SwitchToggle on={grp.enabled > 0} onChange={() => onToggleProvider(key, grp.enabled < grp.total)} />
              <button onClick={() => setExp((prev) => ({ ...prev, [key]: !prev[key] }))} style={{ background: "none", border: "none", color: "#475569", cursor: "pointer", fontSize: "11px" }}>{isExp ? "▲" : "▼"}</button>
            </div>
            {isExp && filtered.length > 0 && (
              <div style={{ marginTop: "4px", display: "flex", flexDirection: "column", gap: "2px" }}>
                {filtered.map((m) => {
                  const en = statusMap.get(m.id) ?? true;
                  return (
                    <div key={m.id} style={{ display: "flex", alignItems: "center", gap: "10px", background: en ? "rgba(0,0,0,0.18)" : "rgba(0,0,0,0.35)", border: `1px solid ${en ? "rgba(255,255,255,0.05)" : "rgba(248,113,113,0.12)"}`, borderRadius: "7px", padding: "6px 12px", opacity: en ? 1 : 0.55 }}>
                      <code style={{ fontFamily: "Menlo, monospace", fontSize: "11.5px", color: en ? c.text : "#475569", flex: 1 }}>{m.id}</code>
                      <span style={{ fontSize: "11.5px", color: "#334155", flexShrink: 0 }}>{m.desc}</span>
                      {m.context && <span style={{ fontSize: "10px", color: "#334155", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "3px", padding: "1px 5px" }}>{m.context}</span>}
                      {m.badge && <BadgeChip variant={m.badge} />}
                      <SwitchToggle on={en} onChange={() => onToggleModel(m.id, !en)} />
                    </div>
                  );
                })}
              </div>
            )}
            {isExp && filtered.length === 0 && <div style={{ padding: "10px 14px", color: "#334155", fontSize: "12.5px" }}>该过滤条件下无匹配模型</div>}
          </div>
        );
      })}
    </>
  );
}

// ─── Page: Endpoints ──────────────────────────────────────────────────────────

function PageEndpoints({ displayUrl }: { displayUrl: string }) {
  const [exp, setExp] = useState<Record<string, boolean>>({ openai: false, anthropic: false, gemini: false, openrouter: false });

  const endpoints: Array<{ method: "GET" | "POST" | "DELETE" | "PATCH"; path: string; desc: string }> = [
    { method: "GET", path: "/v1/models", desc: "列出所有可用模型" },
    { method: "POST", path: "/v1/chat/completions", desc: "OpenAI 格式补全（工具调用 + 流式）" },
    { method: "POST", path: "/v1/messages", desc: "Claude Messages 原生格式" },
    { method: "POST", path: "/v1/models/:model:generateContent", desc: "Gemini 原生格式（非流式）" },
    { method: "POST", path: "/v1/models/:model:streamGenerateContent", desc: "Gemini 原生格式（流式 SSE）" },
    { method: "GET", path: "/v1/stats", desc: "查看各后端用量统计（需 API Key）" },
    { method: "GET", path: "/v1/admin/backends", desc: "列出所有后端节点（需 API Key）" },
    { method: "POST", path: "/v1/admin/backends", desc: "动态添加新节点（需 API Key）" },
    { method: "DELETE", path: "/v1/admin/backends/:label", desc: "移除动态节点（需 API Key）" },
    { method: "PATCH", path: "/v1/admin/routing", desc: "更新路由策略（需 API Key）" },
    { method: "GET", path: "/v1/admin/models", desc: "列出模型启用状态（需 API Key）" },
    { method: "PATCH", path: "/v1/admin/models", desc: "批量启用/禁用模型（需 API Key）" },
  ];

  const modelGroups: Array<{ key: ProviderKey; title: string; models: ModelInfo[] }> = [
    { key: "openai", title: "OpenAI", models: OPENAI_MODELS },
    { key: "anthropic", title: "Anthropic Claude", models: ANTHROPIC_MODELS },
    { key: "gemini", title: "Google Gemini", models: GEMINI_MODELS },
    { key: "openrouter", title: "OpenRouter（任意 provider/model 均可路由）", models: OPENROUTER_MODELS },
  ];

  return (
    <>
      <Card style={{ marginBottom: "14px" }}>
        <SectionTitle>API 端点列表</SectionTitle>
        <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
          {endpoints.map((ep) => (
            <div key={`${ep.method}:${ep.path}`} style={{ display: "flex", alignItems: "center", gap: "10px", background: "rgba(0,0,0,0.2)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: "8px", padding: "10px 14px" }}>
              <MethodTag method={ep.method} />
              <code style={{ color: "#e2e8f0", fontFamily: "Menlo, monospace", fontSize: "12.5px", flex: 1 }}>{ep.path}</code>
              <span style={{ color: "#475569", fontSize: "12px", flexShrink: 0, maxWidth: "220px", textAlign: "right" }}>{ep.desc}</span>
              <CopyBtn text={`${displayUrl}${ep.path}`} />
            </div>
          ))}
        </div>
      </Card>

      <Card style={{ marginBottom: "14px" }}>
        <SectionTitle>认证方式（三选一）</SectionTitle>
        <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
          {[
            { label: "Bearer Token（推荐，兼容所有 OpenAI 客户端）", code: "Authorization: Bearer YOUR_PROXY_API_KEY" },
            { label: "x-goog-api-key Header（兼容 Gemini 格式客户端）", code: "x-goog-api-key: YOUR_PROXY_API_KEY" },
            { label: "URL 查询参数（适合简单调试）", code: `${displayUrl}/v1/models?key=YOUR_PROXY_API_KEY` },
          ].map((a) => (
            <div key={a.label}>
              <div style={{ fontSize: "12px", color: "#64748b", marginBottom: "4px" }}>{a.label}</div>
              <CodeBlock code={a.code} />
            </div>
          ))}
        </div>
      </Card>

      <Card style={{ marginBottom: "14px" }}>
        <SectionTitle>工具 / 函数调用示例</SectionTitle>
        <p style={{ margin: "0 0 12px", color: "#64748b", fontSize: "13px", lineHeight: 1.6 }}>使用 OpenAI 标准 <code style={{ color: "#a78bfa", background: "rgba(167,139,250,0.1)", padding: "1px 5px", borderRadius: "4px" }}>tools</code> 格式，代理自动转换到各后端格式。</p>
        <CodeBlock code={`curl ${displayUrl}/v1/chat/completions \\
  -H "Authorization: Bearer YOUR_PROXY_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "model": "gpt-4.1-mini",
    "messages": [{"role": "user", "content": "北京天气怎么样?"}],
    "tools": [{"type": "function", "function": {"name": "get_weather", "description": "Get weather", "parameters": {"type": "object", "properties": {"city": {"type": "string"}}, "required": ["city"]}}}],
    "tool_choice": "auto"
  }'`} />
        <div style={{ display: "flex", flexWrap: "wrap", gap: "8px", marginTop: "12px" }}>
          {["OpenAI ✓ pass-through", "Anthropic ✓ tool_use 转换", "Gemini ✓ functionDeclarations 转换", "OpenRouter ✓ pass-through"].map((s) => (
            <span key={s} style={{ fontSize: "11px", color: "#4ade80", background: "rgba(74,222,128,0.08)", border: "1px solid rgba(74,222,128,0.2)", borderRadius: "5px", padding: "3px 8px" }}>{s}</span>
          ))}
        </div>
      </Card>

      <Card style={{ marginBottom: "14px" }}>
        <SectionTitle>快速测试</SectionTitle>
        <CodeBlock code={`curl ${displayUrl}/v1/models \\\n  -H "Authorization: Bearer YOUR_PROXY_API_KEY"`} />
        <div style={{ marginTop: "14px" }}>
          <div style={{ fontSize: "12px", color: "#64748b", marginBottom: "8px" }}>流式输出测试：</div>
          <CodeBlock code={`curl ${displayUrl}/v1/chat/completions \\\n  -H "Authorization: Bearer YOUR_PROXY_API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '{"model":"gpt-4.1-mini","messages":[{"role":"user","content":"Hello!"}],"stream":true}'`} />
        </div>
      </Card>

      <Card style={{ marginBottom: "14px" }}>
        <SectionTitle>可用模型（{TOTAL_MODELS} 个）</SectionTitle>
        <div style={{ display: "flex", flexWrap: "wrap", gap: "8px", marginBottom: "14px" }}>
          {(["thinking", "thinking-visible", "tools", "reasoning"] as const).map((v) => (
            <div key={v} style={{ display: "flex", alignItems: "center", gap: "5px" }}>
              <BadgeChip variant={v} />
              <span style={{ fontSize: "11px", color: "#475569" }}>{v === "thinking" ? "扩展思考（隐藏）" : v === "thinking-visible" ? "扩展思考（可见）" : v === "tools" ? "支持工具调用" : "原生推理"}</span>
            </div>
          ))}
        </div>
        {modelGroups.map(({ key, title, models }) => {
          const c = PROVIDER_COLORS[key];
          const isExp = exp[key];
          return (
            <div key={key} style={{ marginBottom: "8px" }}>
              <button onClick={() => setExp((prev) => ({ ...prev, [key]: !prev[key] }))} style={{ width: "100%", display: "flex", alignItems: "center", gap: "10px", background: c.bg, border: `1px solid ${c.border}`, borderRadius: "8px", padding: "8px 14px", cursor: "pointer" }}>
                <div style={{ width: "7px", height: "7px", borderRadius: "50%", background: c.dot, flexShrink: 0 }} />
                <span style={{ fontWeight: 600, color: c.text, fontSize: "13px", flex: 1, textAlign: "left" }}>{title}</span>
                <span style={{ fontSize: "11px", color: "#475569" }}>{models.length} 个</span>
                <span style={{ color: "#475569", fontSize: "11px" }}>{isExp ? "▲" : "▼"}</span>
              </button>
              {isExp && (
                <div style={{ marginTop: "4px", display: "flex", flexDirection: "column", gap: "2px" }}>
                  {models.map((m) => (
                    <div key={m.id} style={{ display: "flex", alignItems: "center", gap: "10px", background: "rgba(0,0,0,0.18)", border: "1px solid rgba(255,255,255,0.05)", borderRadius: "7px", padding: "6px 12px" }}>
                      <code style={{ fontFamily: "Menlo, monospace", fontSize: "11.5px", color: c.text, flex: 1 }}>{m.id}</code>
                      <span style={{ fontSize: "11.5px", color: "#334155", flexShrink: 0 }}>{m.desc}</span>
                      {m.context && <span style={{ fontSize: "10px", color: "#334155", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "3px", padding: "1px 5px" }}>{m.context}</span>}
                      {m.badge && <BadgeChip variant={m.badge} />}
                      <CopyBtn text={m.id} />
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
        <p style={{ margin: "10px 0 0", fontSize: "12px", color: "#334155", lineHeight: 1.5 }}>💡 任何包含 <code style={{ color: "#a78bfa" }}>/</code> 的模型名均自动路由到 OpenRouter，不限于上方列表。</p>
      </Card>
    </>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────

type Tab = "home" | "stats" | "models" | "endpoints";

export default function App() {
  const [tab, setTab] = useState<Tab>("home");
  const [online, setOnline] = useState<boolean | null>(null);
  const [showWizard, setShowWizard] = useState(false);
  const [apiKey, setApiKey] = useState(() => localStorage.getItem("proxy_api_key") ?? "");
  const [sillyTavernMode, setSillyTavernMode] = useState(false);
  const [stLoading, setStLoading] = useState(true);
  const [stats, setStats] = useState<Record<string, NodeStatData> | null>(null);
  const [statsError, setStatsError] = useState<false | "auth" | "server">(false);
  const [routing, setRouting] = useState<RoutingState>({ localEnabled: true, localFallback: true, fakeStream: true });
  const [addUrl, setAddUrl] = useState("");
  const [addState, setAddState] = useState<"idle" | "loading" | "ok" | "err">("idle");
  const [addMsg, setAddMsg] = useState("");
  const [modelStatus, setModelStatus] = useState<ModelRecord[]>([]);
  const [modelSummary, setModelSummary] = useState<Record<string, GroupCount>>({});

  const baseUrl = window.location.origin;
  const displayUrl = (import.meta.env.VITE_BASE_URL as string | undefined) ?? window.location.origin;

  const checkHealth = useCallback(async () => {
    try { const r = await fetch(`${baseUrl}/api/healthz`, { signal: AbortSignal.timeout(5000) }); setOnline(r.ok); }
    catch { setOnline(false); }
  }, [baseUrl]);

  const fetchSTMode = useCallback(async () => {
    try {
      const key = localStorage.getItem("proxy_api_key") ?? "";
      const r = await fetch(`${baseUrl}/api/settings/sillytavern`, { headers: key ? { Authorization: `Bearer ${key}` } : {} });
      if (r.ok) { const d = await r.json() as { enabled: boolean }; setSillyTavernMode(d.enabled); }
    } catch {}
    setStLoading(false);
  }, [baseUrl]);

  const toggleST = async () => {
    const next = !sillyTavernMode; setSillyTavernMode(next);
    try {
      const r = await fetch(`${baseUrl}/api/settings/sillytavern`, { method: "POST", headers: { "Content-Type": "application/json", ...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {}) }, body: JSON.stringify({ enabled: next }) });
      if (!r.ok) setSillyTavernMode(!next);
    } catch { setSillyTavernMode(!next); }
  };

  const fetchStats = useCallback(async (key: string) => {
    if (!key) { setStats(null); setStatsError(false); return; }
    try {
      const r = await fetch(`${baseUrl}/api/v1/stats`, { headers: { Authorization: `Bearer ${key}` } });
      if (!r.ok) { setStatsError(r.status === 500 ? "server" : "auth"); return; }
      const d = await r.json() as { stats: Record<string, NodeStatData>; routing?: RoutingState };
      setStats(d.stats); setStatsError(false);
      if (d.routing) setRouting(d.routing);
    } catch { setStatsError("auth"); }
  }, [baseUrl]);

  const fetchModels = useCallback(async (key: string = apiKey) => {
    if (!key) return;
    try {
      const r = await fetch(`${baseUrl}/api/v1/admin/models`, { headers: { Authorization: `Bearer ${key}` } });
      if (!r.ok) return;
      const d = await r.json() as { models: ModelRecord[]; summary: Record<string, GroupCount> };
      setModelStatus(d.models ?? []); setModelSummary(d.summary ?? {});
    } catch {}
  }, [baseUrl, apiKey]);

  const addBackend = async (e: React.FormEvent) => {
    e.preventDefault();
    const url = normalizeApiUrl(addUrl); if (!url) return;
    setAddState("loading");
    try {
      const r = await fetch(`${baseUrl}/api/v1/admin/backends`, { method: "POST", headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" }, body: JSON.stringify({ url }) });
      const d = await r.json() as { error?: string; label?: string };
      if (!r.ok) { setAddState("err"); setAddMsg(d.error ?? "Failed"); return; }
      setAddState("ok"); setAddMsg(`已添加 ${d.label}`); setAddUrl("");
      setTimeout(() => setAddState("idle"), 3000);
      fetchStats(apiKey);
    } catch { setAddState("err"); setAddMsg("网络错误"); }
  };

  const removeBackend = (label: string) => fetch(`${baseUrl}/api/v1/admin/backends/${label}`, { method: "DELETE", headers: { Authorization: `Bearer ${apiKey}` } }).then(() => fetchStats(apiKey));
  const toggleBackend = (label: string, enabled: boolean) => fetch(`${baseUrl}/api/v1/admin/backends/${label}`, { method: "PATCH", headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" }, body: JSON.stringify({ enabled }) }).then(() => fetchStats(apiKey));
  const batchToggle = (labels: string[], enabled: boolean) => fetch(`${baseUrl}/api/v1/admin/backends`, { method: "PATCH", headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" }, body: JSON.stringify({ labels, enabled }) }).then(() => fetchStats(apiKey));
  const batchRemove = (labels: string[]) => Promise.all(labels.map((l) => fetch(`${baseUrl}/api/v1/admin/backends/${l}`, { method: "DELETE", headers: { Authorization: `Bearer ${apiKey}` } }))).then(() => fetchStats(apiKey));

  const toggleRouting = async (field: keyof RoutingState, value: boolean) => {
    setRouting((p) => ({ ...p, [field]: value }));
    try { await fetch(`${baseUrl}/api/v1/admin/routing`, { method: "PATCH", headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" }, body: JSON.stringify({ [field]: value }) }); } catch {}
  };

  const toggleModelProvider = async (provider: string, enabled: boolean) => {
    setModelStatus((p) => p.map((m) => m.provider === provider ? { ...m, enabled } : m));
    setModelSummary((p) => { const g = p[provider]; if (!g) return p; return { ...p, [provider]: { total: g.total, enabled: enabled ? g.total : 0 } }; });
    try { await fetch(`${baseUrl}/api/v1/admin/models`, { method: "PATCH", headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" }, body: JSON.stringify({ provider, enabled }) }); } catch {}
    fetchModels();
  };

  const toggleModelById = async (id: string, enabled: boolean) => {
    setModelStatus((p) => p.map((m) => m.id === id ? { ...m, enabled } : m));
    try { await fetch(`${baseUrl}/api/v1/admin/models`, { method: "PATCH", headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" }, body: JSON.stringify({ ids: [id], enabled }) }); } catch {}
    fetchModels();
  };

  useEffect(() => {
    checkHealth(); fetchSTMode(); fetchStats(apiKey); fetchModels(apiKey);
    const t1 = setInterval(checkHealth, 30000);
    const t2 = setInterval(() => fetchStats(apiKey), 15000);
    return () => { clearInterval(t1); clearInterval(t2); };
  }, [checkHealth, fetchSTMode, fetchStats, fetchModels, apiKey]);

  useEffect(() => {
    if (sessionStorage.getItem("wizard_dismissed") === "1") return;
    fetch(`${baseUrl}/api/setup-status`).then((r) => r.ok ? r.json() : null)
      .then((d: { configured: boolean } | null) => { if (!d || !d.configured) setShowWizard(true); }).catch(() => {});
  }, [baseUrl]);

  const TABS: Array<{ id: Tab; label: string }> = [
    { id: "home", label: "首页" },
    { id: "stats", label: "统计 & 节点" },
    { id: "models", label: "模型管理" },
    { id: "endpoints", label: "端点文档" },
  ];

  return (
    <div style={{ minHeight: "100vh", background: "hsl(222,47%,11%)", color: "#e2e8f0", fontFamily: "'Inter', -apple-system, sans-serif" }}>
      {showWizard && (
        <SetupWizard
          baseUrl={baseUrl}
          onComplete={(key) => { sessionStorage.setItem("wizard_dismissed", "1"); setShowWizard(false); if (key) { setApiKey(key); localStorage.setItem("proxy_api_key", key); } }}
          onDismiss={() => { sessionStorage.setItem("wizard_dismissed", "1"); setShowWizard(false); }}
        />
      )}

      <UpdateBar baseUrl={baseUrl} />

      <div style={{ maxWidth: "900px", margin: "0 auto", padding: "32px 24px 80px" }}>
        {/* Header */}
        <div style={{ marginBottom: "28px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "8px" }}>
            <div style={{ width: "38px", height: "38px", borderRadius: "10px", background: "linear-gradient(135deg,#6366f1,#8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "19px" }}>⚡</div>
            <h1 style={{ margin: 0, fontSize: "21px", fontWeight: 700, color: "#f1f5f9" }}>AI Gateway</h1>
            <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: "8px" }}>
              <UpdateBadge baseUrl={baseUrl} apiKey={apiKey} />
              <button onClick={() => setShowWizard(true)} style={{ padding: "5px 12px", background: "rgba(99,102,241,0.12)", border: "1px solid rgba(99,102,241,0.25)", borderRadius: "100px", color: "#818cf8", fontSize: "12px", fontWeight: 600, cursor: "pointer" }}>🚀 配置向导</button>
              <div style={{ display: "flex", alignItems: "center", gap: "6px", background: online === null ? "rgba(100,116,139,0.15)" : online ? "rgba(74,222,128,0.12)" : "rgba(248,113,113,0.12)", border: `1px solid ${online === null ? "rgba(100,116,139,0.3)" : online ? "rgba(74,222,128,0.3)" : "rgba(248,113,113,0.3)"}`, borderRadius: "100px", padding: "4px 10px 4px 8px" }}>
                <div style={{ width: "8px", height: "8px", borderRadius: "50%", background: online === null ? "#64748b" : online ? "#4ade80" : "#f87171", boxShadow: online ? "0 0 6px #4ade80" : undefined }} />
                <span style={{ fontSize: "12px", color: online === null ? "#64748b" : online ? "#4ade80" : "#f87171", fontWeight: 600 }}>{online === null ? "检测中" : online ? "在线" : "离线"}</span>
              </div>
            </div>
          </div>
          <p style={{ color: "#64748b", margin: 0, fontSize: "13.5px", lineHeight: 1.6 }}>统一 AI API 网关 · OpenAI / Anthropic / Gemini / OpenRouter · OpenAI 兼容格式</p>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: "4px", marginBottom: "24px", background: "rgba(0,0,0,0.25)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "10px", padding: "4px" }}>
          {TABS.map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{ flex: 1, padding: "8px 12px", borderRadius: "7px", border: "none", background: tab === t.id ? "rgba(99,102,241,0.25)" : "transparent", color: tab === t.id ? "#a5b4fc" : "#475569", fontSize: "13px", fontWeight: tab === t.id ? 600 : 400, cursor: "pointer", transition: "all 0.15s", boxShadow: tab === t.id ? "inset 0 0 0 1px rgba(99,102,241,0.35)" : "none" }}>
              {t.label}
            </button>
          ))}
        </div>

        {tab === "home" && <PageHome displayUrl={displayUrl} apiKey={apiKey} setApiKey={setApiKey} sillyTavernMode={sillyTavernMode} stLoading={stLoading} onToggleSTMode={toggleST} />}
        {tab === "stats" && <PageStats baseUrl={baseUrl} apiKey={apiKey} stats={stats} statsError={statsError} onRefresh={() => fetchStats(apiKey)} addUrl={addUrl} setAddUrl={setAddUrl} addState={addState} addMsg={addMsg} onAddBackend={addBackend} onRemoveBackend={removeBackend} onToggleBackend={toggleBackend} onBatchToggle={batchToggle} onBatchRemove={batchRemove} routing={routing} onToggleRouting={toggleRouting} />}
        {tab === "models" && <PageModels apiKey={apiKey} modelStatus={modelStatus} summary={modelSummary} onRefresh={() => fetchModels(apiKey)} onToggleProvider={toggleModelProvider} onToggleModel={toggleModelById} />}
        {tab === "endpoints" && <PageEndpoints displayUrl={displayUrl} />}

        <div style={{ marginTop: "32px", textAlign: "center", color: "#1e293b", fontSize: "12px" }}>
          Powered by Replit AI Integrations · OpenAI · Anthropic · Gemini · OpenRouter
        </div>
      </div>
    </div>
  );
}
